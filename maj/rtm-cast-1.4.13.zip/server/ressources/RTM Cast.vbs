' RTM Cast - lancement INVISIBLE (aucune fenetre noire).
' Double-clic : demarre RTM Cast en arriere-plan (s'il ne tourne pas deja) et ouvre la regie.
' Argument /demarrage : utilise au demarrage de Windows, n'ouvre pas la regie.
' Pour arreter RTM Cast : regie > bouton "Arreter RTM Cast".
Option Explicit
Dim sh, fso, dossier, node, demarrage, rc, port
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dossier = fso.GetParentFolderName(WScript.ScriptFullName)
node = dossier & "\node\node.exe"
If Not fso.FileExists(node) Then node = "node"
port = LirePort()
demarrage = (WScript.Arguments.Count > 0)
' Signale a RTM Cast qu'il tourne sans fenetre
sh.Environment("PROCESS")("RTM_LANCEUR") = "vbs"

' Port de RTM Cast (config.json), 8095 par defaut
Function LirePort()
  Dim f, t, re, m
  LirePort = "8095"
  On Error Resume Next
  f = sh.ExpandEnvironmentStrings("%APPDATA%") & "\RTM Cast\config.json"
  If fso.FileExists(f) Then
    t = fso.OpenTextFile(f, 1).ReadAll
    Set re = New RegExp
    re.Pattern = """port""\s*:\s*(\d{2,5})"
    Set m = re.Execute(t)
    If m.Count > 0 Then LirePort = m(0).SubMatches(0)
  End If
  On Error GoTo 0
End Function

Function DejaLance()
  Dim x
  DejaLance = False
  On Error Resume Next
  Set x = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  x.setTimeouts 2000, 2000, 2000, 2000
  x.Open "GET", "http://127.0.0.1:" & port & "/api/version", False
  x.Send
  If Err.Number = 0 Then
    If x.Status = 200 Then DejaLance = True
  End If
  On Error GoTo 0
End Function

If DejaLance() Then
  If Not demarrage Then sh.Run "http://localhost:" & port & "/regie"
  WScript.Quit 0
End If

If Not demarrage Then
  ' ouvre la regie quelques secondes apres le demarrage (fenetre cachee)
  sh.Run "cmd /c timeout /t 4 /nobreak >nul & start """" http://localhost:" & port & "/regie", 0, False
End If

' Boucle : si RTM Cast s'arrete (coupure, mise a jour), il redemarre tout seul.
' Code 2 = deja ouvert ; code 4 = arret demande depuis la regie.
Do
  rc = sh.Run("""" & node & """ """ & dossier & "\lanceur.js""", 0, True)
  If rc = 2 Or rc = 4 Then Exit Do
  WScript.Sleep 5000
Loop
