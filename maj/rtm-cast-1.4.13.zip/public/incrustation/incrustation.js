/* Incrustation des J'aime à l'antenne (vMix > Add Input > Web Browser). */
(function () {
  'use strict';
  const cle = new URLSearchParams(location.search).get('cle') || '';
  let dernier = -1;
  const $ = (id) => document.getElementById(id);
  const format = (n) => n.toLocaleString('fr-FR');

  function coeur() {
    const c = document.createElement('div');
    c.className = 'coeur-vol';
    c.textContent = '❤';
    c.style.left = `${Math.round(Math.random() * 160)}px`;
    c.style.setProperty('--dx', `${Math.round((Math.random() - 0.5) * 140)}px`);
    c.style.setProperty('--rot', `${Math.round((Math.random() - 0.5) * 50)}deg`);
    $('scene').append(c);
    setTimeout(() => c.remove(), 3300);
  }

  function annonce(nom, n) {
    const a = document.createElement('div');
    a.className = 'annonce';
    const t = document.createElement('span');
    t.textContent = `${nom} a aimé `;
    const c = document.createElement('span');
    c.className = 'c';
    c.textContent = n > 1 ? `❤ ×${n}` : '❤';
    a.append(t, c);
    $('annonces').append(a);
    while ($('annonces').children.length > 4) $('annonces').firstChild.remove();
    setTimeout(() => a.remove(), 5200);
  }

  async function tour() {
    try {
      const r = await fetch(`/api/incrustation?cle=${encodeURIComponent(cle)}&depuis=${Math.max(dernier, 0)}`, { cache: 'no-store' });
      if (!r.ok) return;
      const d = await r.json();
      $('total').textContent = format(d.total);
      if (dernier >= 0) {
        for (const x of d.nouveaux) {
          annonce(x.nom, x.n);
          for (let i = 0; i < Math.min(x.n, 12); i++) setTimeout(coeur, i * 140);
        }
      }
      dernier = d.dernier;
    } catch { /* réessai */ }
  }
  tour();
  setInterval(tour, 1500);
})();
