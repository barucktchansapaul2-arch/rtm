'use strict';
// RTM Cast — serveur de diffusion locale « comme Castr » pour RTM Télévision (Moba).
// vMix ──RTMP──> ffmpeg ──HLS──> appli mobile « RTM Direct » (+ régie web).
const http = require('node:http');
const net = require('node:net');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const auth = require('./lib/auth');
const { verifierCommentaire, DELAI_MS } = require('./lib/moderation');
const grilleLib = require('./lib/grille');
const { Spectateurs } = require('./lib/viewers');
const { JsonStore } = require('./lib/store');
const { dossierDonnees, chargerConfig } = require('./lib/config');
const { Ingest } = require('./lib/ingest');
const { Tunnel, jetonValide } = require('./lib/tunnel');
const { MiseAJour } = require('./lib/maj');
const { Publication } = require('./lib/publication');
const installation = require('./lib/installation');
const { Bouclier } = require('./lib/bouclier');

const RACINE = path.resolve(__dirname, '..');
const PUBLIC = path.join(RACINE, 'public');
const CORPS_MAX = 16 * 1024;
const PHOTO_MAX = 220 * 1024;            // corps de requête pour une photo de profil (base64)
const VERSION = require('../package.json').version;
const COOKIE = 'rtm_s';
const SESSION_MS = 90 * 24 * 3600 * 1000;
const REGIE_MS = 12 * 3600 * 1000;

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.m3u8': 'application/vnd.apple.mpegurl', '.ts': 'video/mp2t',
  '.txt': 'text/plain; charset=utf-8',
  '.apk': 'application/vnd.android.package-archive',
  '.jpg': 'image/jpeg',
};

const SECURITE = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; worker-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
};

class ErreurHttp extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

// Limiteur simple : n essais par fenêtre.
class Limiteur {
  constructor(max, fenetreMs) { this.max = max; this.fenetre = fenetreMs; this.m = new Map(); }
  depasse(cle, maintenant = Date.now()) {
    const e = this.m.get(cle);
    if (!e || maintenant - e.t > this.fenetre) { this.m.set(cle, { t: maintenant, n: 1 }); this.purger(maintenant); return false; }
    e.n += 1;
    return e.n > this.max;
  }
  effacer(cle) { this.m.delete(cle); }
  // Mémoire bornée : au-delà du plafond, on retire les expirées puis les plus anciennes.
  purger(maintenant) {
    if (this.m.size <= Limiteur.PLAFOND) return;
    for (const [k, e] of this.m) if (maintenant - e.t > this.fenetre) this.m.delete(k);
    for (const k of this.m.keys()) { if (this.m.size <= Limiteur.PLAFOND * 0.9) break; this.m.delete(k); }
  }
}
Limiteur.PLAFOND = 20_000;

// Plafond global d'échecs (toutes adresses confondues) pour la régie.
class PlafondGlobal {
  constructor(max, fenetreMs) { this.max = max; this.fenetre = fenetreMs; this.echecs = []; }
  bloque(maintenant = Date.now()) {
    while (this.echecs.length && maintenant - this.echecs[0] > this.fenetre) this.echecs.shift();
    return this.echecs.length >= this.max;
  }
  echec(maintenant = Date.now()) { this.echecs.push(maintenant); if (this.echecs.length > this.max * 2) this.echecs.shift(); }
}

function adressesLocales(port) {
  const r = [];
  for (const liste of Object.values(os.networkInterfaces())) {
    for (const i of liste || []) if (i.family === 'IPv4' && !i.internal) r.push(`http://${i.address}:${port}`);
  }
  return r;
}

async function demarrer(options = {}) {
  const dataDir = options.dataDir || dossierDonnees();
  fs.mkdirSync(dataDir, { recursive: true });
  const config = chargerConfig(dataDir);
  const hlsDir = path.join(dataDir, 'hls');
  fs.mkdirSync(hlsDir, { recursive: true });

  const utilisateurs = new JsonStore(path.join(dataDir, 'utilisateurs.json'), { liste: [] });
  const sessions = new JsonStore(path.join(dataDir, 'sessions.json'), { jetons: {} });
  const commentaires = new JsonStore(path.join(dataDir, 'commentaires.json'), { liste: [], version: 0 });
  const jaime = new JsonStore(path.join(dataDir, 'jaime.json'), { total: 0, par: {} });
  // Ancien format (un J'aime par personne) -> compteur façon TikTok (plusieurs tapes).
  if (Array.isArray(jaime.data.ids)) {
    for (const id of jaime.data.ids) jaime.data.par[id] = (jaime.data.par[id] || 0) + 1;
    jaime.data.total = (jaime.data.total || 0) + jaime.data.ids.length;
    delete jaime.data.ids;
    jaime.save();
  }
  const dossierPhotos = path.join(dataDir, 'photos');
  fs.mkdirSync(dossierPhotos, { recursive: true });
  const rafaleJaime = new Map(); // anti-robot : 100 tapes / 10 s / personne
  // Derniers J'aime (pour la régie et l'incrustation à l'antenne) — jamais montrés au public.
  const flotJaime = [];
  let numeroJaime = 0;
  const infos = new JsonStore(path.join(dataDir, 'infos.json'), { liste: [] });
  const sessionsRegie = new Map();
  const spectateurs = new Spectateurs();
  const limiteIp = new Limiteur(300, 10 * 60_000);   // par adresse : CGNAT, beaucoup de connexions au début d'une émission
  // Par (contact + adresse) : un inconnu ne peut pas bloquer le compte de quelqu'un d'autre.
  const limiteContactIp = new Limiteur(8, 15 * 60_000);
  const limiteContact = new Limiteur(40, 15 * 60_000);
  const limiteRegie = new Limiteur(8, 15 * 60_000);
  const plafondRegie = new PlafondGlobal(30, 60 * 60_000);
  const limitePing = new Limiteur(8, 60_000);        // par appareil
  const limitePingIp = new Limiteur(6000, 60_000);  // par adresse (CGNAT : beaucoup d'appareils)
  const limitePhoto = new Limiteur(5, 3600_000);
  const bouclier = new Bouclier({ fichier: path.join(dataDir, 'securite.json'), journal, outilsTolere: !!options.outilsTolere });
  // Qui est en ligne (point vert, comme Facebook) : dernier signe de vie par compte.
  const enLigne = new Map();
  const EN_LIGNE_MS = 45_000;
  function membresEnLigne() {
    const t = Date.now();
    const ids = [];
    for (const [id, vu] of enLigne) { if (t - vu > EN_LIGNE_MS) enLigne.delete(id); else ids.push(id); }
    return ids;
  }
  const dernierCommentaire = new Map();
  const lignesJournal = [];

  const fichierJournal = path.join(dataDir, 'journal.txt');
  function journal(niveau, texte) {
    const d = new Date();
    const l = `${d.toLocaleDateString('fr-FR')} ${d.toLocaleTimeString('fr-FR')}  ${niveau.padEnd(6)}  ${texte}`;
    lignesJournal.push(l);
    if (lignesJournal.length > 200) lignesJournal.shift();
    try {
      if (fs.existsSync(fichierJournal) && fs.statSync(fichierJournal).size > 5 * 1024 * 1024) {
        fs.renameSync(fichierJournal, path.join(dataDir, 'journal.ancien.txt'));
      }
      fs.appendFileSync(fichierJournal, l + '\n');
    } catch { /* disque plein */ }
    if (!options.silencieux) console.log(l);
  }
  for (const s of [utilisateurs, sessions, commentaires, jaime, infos]) {
    s.surErreur = (e) => journal('ERREUR', `Écriture impossible (${path.basename(s.fichier)}) : ${e.code || e.message} — nouvel essai.`);
  }

  // Purge des sessions expirées : au démarrage puis toutes les heures.
  function purgerSessions() {
    const t = Date.now();
    let change = false;
    for (const [h, s] of Object.entries(sessions.data.jetons)) if (!s || s.exp < t) { delete sessions.data.jetons[h]; change = true; }
    for (const [h, exp] of sessionsRegie) if (exp < t) sessionsRegie.delete(h);
    for (const [u, d] of dernierCommentaire) if (t - d > 60_000) dernierCommentaire.delete(u);
    if (change) sessions.saveBientot();
  }
  purgerSessions();
  const minuteurPurge = setInterval(purgerSessions, 3600_000);
  minuteurPurge.unref?.();

  const ingest = new Ingest({ config, dossier: hlsDir, racineAppli: RACINE, journal, fichierPid: path.join(dataDir, 'ffmpeg.pid') });

  let tunnel = null;
  let portEcoute = 0;
  let maj = null;
  let publication = null;
  // Version de l'APK Android distribuée par ce serveur (écrite par outils/fabriquer-apk.ps1).
  let APK = { version: '1.0', code: 1 };
  try { APK = { ...APK, ...JSON.parse(fs.readFileSync(path.join(PUBLIC, 'telechargement', 'apk.json'), 'utf8')) }; } catch { /* pas d'APK */ }
  function lienPublic() {
    if (config.data.adressePublique) return config.data.adressePublique;
    if (tunnel && tunnel.etat === 'actif' && tunnel.url) return tunnel.url;
    return '';
  }

  function hoteLocal(valeur) {
    try {
      const u = new URL(valeur.includes('://') ? valeur : `http://${valeur}`);
      return ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname) && (!u.port || Number(u.port) === portEcoute);
    } catch { return false; }
  }
  function estLocal(req) {
    if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) return false;
    if (req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for']) return false;
    // Une page internet ouverte sur ce PC ne peut pas se faire passer pour la régie locale.
    if (!hoteLocal(String(req.headers.host || ''))) return false;
    const origine = req.headers.origin;
    return !origine || hoteLocal(String(origine));
  }

  // ---------- grille (RTM Diffusion Auto) ----------
  let grilleCache = { t: 0, data: null };
  function grille() {
    if (Date.now() - grilleCache.t < 30_000) return grilleCache.data;
    let data = null;
    try { data = JSON.parse(fs.readFileSync(config.data.grille, 'utf8')); } catch { /* pas de grille */ }
    grilleCache = { t: Date.now(), data };
    return data;
  }

  function estEnDirect() {
    for (const f of ['hd.m3u8', 'eco.m3u8']) {
      try { if (Date.now() - fs.statSync(path.join(hlsDir, f)).mtimeMs < 15_000) return true; } catch { /* absent */ }
    }
    return false;
  }

  // ---------- outils HTTP ----------
  function envoyer(res, status, corps, entetes = {}) {
    res.writeHead(status, { ...SECURITE, ...entetes });
    res.end(corps);
  }
  function json(res, status, obj) {
    envoyer(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  }

  function lireCorps(req, max = CORPS_MAX) {
    return new Promise((ok, ko) => {
      let taille = 0;
      const morceaux = [];
      let trop = false;
      req.on('data', (m) => {
        taille += m.length;
        if (taille > max) { trop = true; morceaux.length = 0; return; }
        morceaux.push(m);
      });
      req.on('end', () => {
        if (trop) return ko(new ErreurHttp(413, 'Message trop long.'));
        if (!taille) return ok({});
        try {
          const v = JSON.parse(Buffer.concat(morceaux).toString('utf8'));
          ok(v && typeof v === 'object' && !Array.isArray(v) ? v : {});
        } catch { ko(new ErreurHttp(400, 'Requête invalide.')); }
      });
      req.on('error', ko);
    });
  }

  // Adresse du visiteur. IPv4 « ::ffff:a.b.c.d » -> « a.b.c.d » ; IPv6 regroupée par /64
  // (un téléphone IPv6 change d'adresse à volonté dans son /64 : on le suit quand même).
  function normaliserIp(ip) {
    if (!ip) return '';
    if (ip.startsWith('::ffff:') && net.isIPv4(ip.slice(7))) return ip.slice(7);
    if (net.isIPv6(ip)) {
      const [g, d = ''] = ip.split('::');
      const gauche = g ? g.split(':') : [];
      const droite = d ? d.split(':') : [];
      const groupes = ip.includes('::') ? [...gauche, ...Array(8 - gauche.length - droite.length).fill('0'), ...droite] : gauche;
      return groupes.slice(0, 4).map((x) => x.toLowerCase().replace(/^0+(?=.)/, '')).join(':') + '::/64';
    }
    return ip;
  }

  function ipDe(req) {
    const a = req.socket.remoteAddress || '';
    // Derrière le tunnel local (cloudflared), l'adresse réelle est dans l'en-tête — si elle est valide.
    if ((a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1') && req.headers['cf-connecting-ip']) {
      const h = String(req.headers['cf-connecting-ip']).trim();
      if (net.isIP(h) && !['127.0.0.1', '::1'].includes(h)) return normaliserIp(h);
      return 'invalide';
    }
    return normaliserIp(a) || a;
  }

  function jetonDe(req) {
    const h = req.headers.authorization || '';
    return h.startsWith('Bearer ') ? h.slice(7).trim() : '';
  }

  function lireCookie(req, nom) {
    const c = req.headers.cookie || '';
    for (const morceau of c.split(';')) {
      const i = morceau.indexOf('=');
      if (i > 0 && morceau.slice(0, i).trim() === nom) return morceau.slice(i + 1).trim();
    }
    return '';
  }

  // Le cookie n'est accepté que pour les lectures (GET) : pas de risque CSRF.
  // Il sert au lecteur vidéo (HLS) et aux photos, qui ne peuvent pas envoyer d'en-tête.
  function jetonUtilisateur(req) {
    return jetonDe(req) || (req.method === 'GET' || req.method === 'HEAD' ? lireCookie(req, COOKIE) : '');
  }

  function cookieSession(req, jeton, maxAge) {
    const https = String(req.headers['x-forwarded-proto'] || '').includes('https') || String(req.headers['cf-visitor'] || '').includes('https');
    return `${COOKIE}=${jeton}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.round(maxAge)}${https ? '; Secure' : ''}`;
  }

  function utilisateurConnecte(req) {
    const t = jetonUtilisateur(req);
    if (!t) return null;
    const s = sessions.data.jetons[auth.hashToken(t)];
    if (!s || s.exp < Date.now()) return null;
    return utilisateurs.data.liste.find((u) => u.id === s.u) || null;
  }

  function exigerUtilisateur(req) {
    const u = utilisateurConnecte(req);
    if (!u) throw new ErreurHttp(401, 'Connectez-vous pour continuer.');
    return u;
  }

  function verifierCleIncrustation(req, url) {
    const fournie = Buffer.from(String(url.searchParams.get('cle') || ''));
    const attendue = Buffer.from(String(config.data.cleIncrustation || ''));
    const ok = attendue.length >= 16 && fournie.length === attendue.length && crypto.timingSafeEqual(fournie, attendue);
    // Jamais depuis internet : seulement vMix sur ce PC ou sur le réseau local.
    if (!ok || req.headers['cf-connecting-ip']) throw new ErreurHttp(403, 'Accès refusé.');
  }

  function exigerRegie(req) {
    const t = jetonDe(req);
    const s = t && sessionsRegie.get(auth.hashToken(t));
    if (!s || s < Date.now()) throw new ErreurHttp(401, 'Connexion à la régie requise.');
  }

  const urlPhoto = (u) => (u && u.photo ? `/photos/${u.id}.jpg?v=${u.photo}` : null);
  const profil = (u) => ({
    id: u.id, nom: u.nom,
    photo: urlPhoto(u), bloque: !!u.bloque,
  });

  function ouvrirSession(u) {
    const { token, hash } = auth.newToken();
    sessions.data.jetons[hash] = { u: u.id, exp: Date.now() + SESSION_MS };
    sessions.saveBientot(300);
    return token;
  }

  function ouvrirSessionRegie() {
    const { token, hash } = auth.newToken();
    sessionsRegie.set(hash, Date.now() + REGIE_MS);
    return token;
  }

  function commentairesPublics() {
    const parId = new Map(utilisateurs.data.liste.map((u) => [u.id, u]));
    const liste = commentaires.data.liste;
    // 80 derniers commentaires principaux + toutes leurs réponses.
    const principaux = liste.filter((c) => !c.parent).slice(-80);
    const gardes = new Set(principaux.map((c) => c.id));
    return liste.filter((c) => gardes.has(c.id) || (c.parent && gardes.has(c.parent))).map((c) => ({
      id: c.id, utilisateur: c.u, auteur: c.auteur, texte: c.texte, t: c.t,
      parent: c.parent || null, photo: urlPhoto(parId.get(c.u)),
    }));
  }

  function changerCommentaires() {
    commentaires.data.version = (commentaires.data.version || 0) + 1;
    commentaires.saveBientot();
  }

  // ---------- fichiers statiques ----------
  function servirFichier(res, racine, relatif, entetes = {}) {
    let rel;
    try { rel = decodeURIComponent(relatif); } catch { return envoyer(res, 400, 'Requête invalide.'); }
    if (!rel || rel.includes('\0') || rel.includes('..') || rel.includes('\\') || path.isAbsolute(rel)) {
      return envoyer(res, 404, 'Introuvable.');
    }
    const complet = path.resolve(racine, rel);
    if (!complet.startsWith(path.resolve(racine) + path.sep)) return envoyer(res, 404, 'Introuvable.');
    fs.stat(complet, (err, st) => {
      if (err || !st.isFile()) return envoyer(res, 404, 'Introuvable.');
      const type = TYPES[path.extname(complet).toLowerCase()] || 'application/octet-stream';
      res.writeHead(200, { ...SECURITE, 'Content-Type': type, 'Content-Length': st.size, ...entetes });
      fs.createReadStream(complet).on('error', () => res.destroy()).pipe(res);
    });
  }

  // ---------- routes API ----------
  const routes = {
    'GET /api/etat': () => {
      const g = grilleLib.programmeA(grille());
      return {
        direct: estEnDirect(),
        maintenant: g.maintenant, ensuite: g.ensuite,
        nomChaine: config.data.nomChaine, sousTitre: config.data.sousTitre,
        commentaires: commentaires.data.liste.length, versionCommentaires: commentaires.data.version || 0,
        // Change à chaque nouvelle réception : l'appli relance alors le lecteur.
        session: ingest.debut || 0, eco: !!config.data.qualiteEco,
        // Lien à partager : l'adresse Internet si elle existe (même vu depuis le Wi-Fi local).
        lienPartage: lienPublic(), lienOfficiel: config.data.lienOfficiel || '', youtube: config.data.lienYoutube || '',
        version: VERSION,
      };
    },
    'GET /api/incrustation': (req, b, url) => {
      verifierCleIncrustation(req, url);
      const depuis = Number(url.searchParams.get('depuis')) || 0;
      return { total: jaime.data.total || 0, nouveaux: flotJaime.filter((x) => x.no > depuis).slice(-30).map((x) => ({ no: x.no, nom: x.nom, n: x.n })), dernier: numeroJaime };
    },
    'GET /api/version': () => ({ serveur: VERSION, apk: { version: APK.version, code: APK.code } }),
    'POST /api/ping': (req, b) => {
      if (!limitePing.depasse(`${ipDe(req)}|${String(b.id || '').slice(0, 64)}`) && !limitePingIp.depasse(ipDe(req))) {
        spectateurs.ping(b.id);
        const u = utilisateurConnecte(req);
        if (u && !u.bloque && (enLigne.has(u.id) || enLigne.size < 50_000)) enLigne.set(u.id, Date.now());
      }
      return { ok: true };
    },
    // Liste des comptes en ligne (réservée aux membres) : sert aux points verts.
    'GET /api/en-ligne': (req) => {
      exigerUtilisateur(req);
      return { ids: membresEnLigne().slice(0, 2000) };
    },
    'GET /api/programmes': (req) => {
      exigerUtilisateur(req);
      const g = grille();
      const auj = new Date();
      return { aujourdhui: grilleLib.journee(g, auj), ...grilleLib.programmeA(g, auj) };
    },
    'GET /api/infos': (req) => { exigerUtilisateur(req); return { infos: infos.data.liste.slice(0, 30) }; },
    'GET /api/commentaires': (req, b, url) => {
      exigerUtilisateur(req);
      const v = commentaires.data.version || 0;
      if (url.searchParams.get('v') === String(v)) return { inchange: true, version: v };
      return { version: v, total: commentaires.data.liste.length, commentaires: commentairesPublics() };
    },

    'POST /api/inscription': (req, b) => {
      if (limiteIp.depasse('i:' + ipDe(req))) throw new ErreurHttp(429, 'Trop d\'essais. Réessayez dans quelques minutes.');
      const v = auth.validateSignup(b);
      if (!v.ok) throw new ErreurHttp(400, v.erreur);
      if (utilisateurs.data.liste.some((u) => u.contact === v.contact.value)) {
        throw new ErreurHttp(409, 'Un compte existe déjà avec ce numéro ou cet e-mail.');
      }
      const u = {
        id: crypto.randomBytes(8).toString('hex'), nom: v.nom, contact: v.contact.value, type: v.contact.type,
        hash: auth.hashPassword(b.motDePasse), cree: Date.now(), bloque: false,
      };
      utilisateurs.data.liste.push(u);
      utilisateurs.save();
      journal('INFO', `Nouveau compte : ${u.nom}`);
      const jeton = ouvrirSession(u);
      return [201, { jeton, utilisateur: profil(u) }, { 'Set-Cookie': cookieSession(req, jeton, SESSION_MS / 1000) }];
    },
    'POST /api/connexion': (req, b) => {
      const c = auth.normalizeContact(b.contact);
      const ip = ipDe(req);
      if (limiteIp.depasse('c:' + ip) || (c && (limiteContactIp.depasse(c.value + '|' + ip) || limiteContact.depasse(c.value)))) {
        throw new ErreurHttp(429, 'Trop d\'essais. Réessayez dans 15 minutes.');
      }
      const u = c && utilisateurs.data.liste.find((x) => x.contact === c.value);
      const bon = auth.verifyPassword(b.motDePasse, u ? u.hash : 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$' + 'A'.repeat(43) + '=');
      if (!u || !bon) throw new ErreurHttp(401, 'Numéro / e-mail ou mot de passe incorrect.');
      limiteContactIp.effacer(c.value + '|' + ip);
      const jeton = ouvrirSession(u);
      return [200, { jeton, utilisateur: profil(u) }, { 'Set-Cookie': cookieSession(req, jeton, SESSION_MS / 1000) }];
    },
    'GET /api/moi': (req) => {
      const u = exigerUtilisateur(req);
      // (Re)pose le cookie du lecteur vidéo pour les comptes déjà connectés.
      const t = jetonDe(req);
      return [200, { utilisateur: profil(u) }, t ? { 'Set-Cookie': cookieSession(req, t, SESSION_MS / 1000) } : {}];
    },
    'POST /api/deconnexion': (req) => {
      const t = jetonDe(req);
      if (t) { delete sessions.data.jetons[auth.hashToken(t)]; sessions.saveBientot(300); }
      return [200, { ok: true }, { 'Set-Cookie': cookieSession(req, '', 0) }];
    },
    'POST /api/moi/photo': (req, b) => {
      const u = exigerUtilisateur(req);
      if (u.bloque) throw new ErreurHttp(403, 'Votre compte est bloqué.');
      if (limitePhoto.depasse(u.id)) throw new ErreurHttp(429, 'Trop de changements de photo. Réessayez dans une heure.');
      const fichier = path.join(dossierPhotos, `${u.id}.jpg`);
      if (b.supprimer === true) {
        try { fs.unlinkSync(fichier); } catch { /* absente */ }
        u.photo = null;
      } else {
        const m = /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/.exec(typeof b.image === 'string' ? b.image : '');
        const octets = m ? Buffer.from(m[1], 'base64') : null;
        if (!octets || octets.length < 500 || octets.length > 160 * 1024 || octets[0] !== 0xff || octets[1] !== 0xd8 || octets[2] !== 0xff) {
          throw new ErreurHttp(400, 'Photo invalide (JPEG, 160 Ko au plus).');
        }
        fs.writeFileSync(fichier, octets);
        u.photo = Date.now();
      }
      utilisateurs.saveBientot(300);
      if (commentaires.data.liste.some((c) => c.u === u.id)) changerCommentaires(); // ses avatars changent
      return { utilisateur: profil(u) };
    },
    'POST /api/commentaires': (req, b) => {
      const u = exigerUtilisateur(req);
      if (u.bloque) throw new ErreurHttp(403, 'Votre compte ne peut plus commenter.');
      const r = verifierCommentaire(b.texte, { dernier: dernierCommentaire.get(u.id) || 0, maintenant: Date.now() });
      if (!r.ok) throw new ErreurHttp(r.attente ? 429 : 400, r.raison);
      // Réponse : toujours rattachée au commentaire principal (un seul niveau, comme TikTok).
      let parent = null;
      if (b.parent !== undefined && b.parent !== null) {
        const vise = commentaires.data.liste.find((x) => x.id === b.parent);
        if (!vise) throw new ErreurHttp(404, 'Ce commentaire n’existe plus.');
        parent = vise.parent || vise.id;
      }
      dernierCommentaire.set(u.id, Date.now());
      const c = { id: crypto.randomBytes(6).toString('hex'), u: u.id, auteur: u.nom, texte: r.texte, t: Date.now() };
      if (parent) c.parent = parent;
      commentaires.data.liste.push(c);
      if (commentaires.data.liste.length > 3000) commentaires.data.liste.splice(0, commentaires.data.liste.length - 3000);
      changerCommentaires();
      return [201, { commentaire: { id: c.id, utilisateur: c.u, auteur: c.auteur, texte: c.texte, t: c.t, parent: c.parent || null, photo: urlPhoto(u) }, delaiMs: DELAI_MS }];
    },
    // J'aime façon TikTok : chaque tape compte. L'appli regroupe les tapes (n = 1 à 50).
    'POST /api/jaime': (req, b) => {
      const u = exigerUtilisateur(req);
      if (u.bloque) throw new ErreurHttp(403, 'Votre compte est bloqué.');
      let n = Number.isInteger(b.n) ? b.n : 1;
      n = Math.max(1, Math.min(50, n));
      const t = Date.now();
      const r = rafaleJaime.get(u.id);
      if (!r || t - r.t > 10_000) rafaleJaime.set(u.id, { t, n });
      else {
        if (r.n >= 100) return { ok: true, limite: true };
        n = Math.min(n, 100 - r.n);
        r.n += n;
      }
      if (rafaleJaime.size > 20_000) { for (const [k, v] of rafaleJaime) if (t - v.t > 10_000) rafaleJaime.delete(k); }
      jaime.data.par[u.id] = (jaime.data.par[u.id] || 0) + n;
      jaime.data.total = (jaime.data.total || 0) + n;
      jaime.saveBientot();
      flotJaime.push({ no: ++numeroJaime, u: u.id, nom: u.nom, n, t });
      if (flotJaime.length > 200) flotJaime.shift();
      // Le public ne voit aucun chiffre : seul le propriétaire (régie, incrustation) les voit.
      return { ok: true };
    },

    // ---------- régie ----------
    'GET /api/regie/statut': () => ({ initialisee: !!config.data.regieHash }),
    'POST /api/regie/initialiser': (req, b) => {
      if (config.data.regieHash) throw new ErreurHttp(409, 'Le mot de passe de la régie existe déjà.');
      if (!estLocal(req) && !options.initialisationDistante) throw new ErreurHttp(403, 'Créez le mot de passe de la régie depuis le PC de diffusion (http://localhost).');
      if (typeof b.motDePasse !== 'string' || b.motDePasse.length < 12) throw new ErreurHttp(400, 'Au moins 12 caractères (mot de passe de l\u2019entreprise).');
      if (auth.motDePasseRegieFaible(b.motDePasse)) throw new ErreurHttp(400, 'Mot de passe trop facile : mélangez au moins 3 sortes de caractères (majuscules, minuscules, chiffres, signes).');
      config.data.regieHash = auth.hashPassword(b.motDePasse);
      config.save();
      journal('INFO', 'Mot de passe de la régie créé.');
      return { jeton: ouvrirSessionRegie() };
    },
    'POST /api/regie/connexion': (req, b) => {
      const local = estLocal(req);
      if (!local && (limiteRegie.depasse(ipDe(req)) || plafondRegie.bloque())) {
        throw new ErreurHttp(429, 'Trop d\'essais. Réessayez plus tard (ou connectez-vous depuis le PC de diffusion).');
      }
      if (!config.data.regieHash || !auth.verifyPassword(b.motDePasse, config.data.regieHash)) {
        if (!local) plafondRegie.echec();
        if (plafondRegie.bloque() && !local) journal('ALERTE', 'Nombreux essais de mot de passe régie depuis internet : connexion distante suspendue 1 h.');
        throw new ErreurHttp(401, 'Mot de passe incorrect.');
      }
      limiteRegie.effacer(ipDe(req));
      return { jeton: ouvrirSessionRegie() };
    },
    'POST /api/regie/deconnexion': (req) => { sessionsRegie.delete(auth.hashToken(jetonDe(req))); return { ok: true }; },
    'GET /api/regie/etat': (req) => {
      exigerRegie(req);
      const c = config.data;
      const hote = c.rtmpBind === '0.0.0.0' ? (adressesLocales(1)[0] || 'http://127.0.0.1:1').replace(/^http:\/\/|:1$/g, '') : '127.0.0.1';
      return {
        ingest: ingest.resume(), tunnel: tunnel ? tunnel.resume() : null, direct: estEnDirect(), spectateurs: spectateurs.compter(),
        rtmp: { url: `rtmp://${hote}:${c.rtmpPort}/live`, cle: c.cle }, membresEnLigne: membresEnLigne().length,
        adresses: adressesLocales(c.port), adressePublique: c.adressePublique,
        reglages: { lienYoutube: c.lienYoutube || '', regieDistante: !!c.regieDistante, qualiteEco: c.qualiteEco, rtmpBind: c.rtmpBind, nomChaine: c.nomChaine, sousTitre: c.sousTitre, adressePublique: c.adressePublique, ffmpeg: c.ffmpeg, grille: c.grille },
        totaux: { utilisateurs: utilisateurs.data.liste.length, commentaires: commentaires.data.liste.length, jaime: jaime.data.total || 0 },
        version: VERSION, maj: maj ? maj.resume() : null, publication: publication ? publication.resume() : null,
        incrustation: `/incrustation/?cle=${config.data.cleIncrustation}`,
        apk: APK, lienOfficiel: config.data.lienOfficiel,
        grilleTrouvee: !!grille(),
        journal: lignesJournal.slice(-60),
      };
    },
    'POST /api/regie/reglages': (req, b) => {
      exigerRegie(req);
      const c = config.data;
      const avant = { qualiteEco: c.qualiteEco, rtmpBind: c.rtmpBind, ffmpeg: c.ffmpeg };
      // Chemins de fichiers : seulement depuis le PC de diffusion, jamais de chemin réseau.
      for (const k of ['ffmpeg', 'grille']) {
        if (typeof b[k] !== 'string' || b[k].trim() === (c[k] || '')) continue;
        if (!estLocal(req)) throw new ErreurHttp(403, 'Les chemins de ffmpeg et de la grille se changent depuis le PC de diffusion.');
        if (/^(\\\\|\/\/)/.test(b[k].trim())) throw new ErreurHttp(400, 'Les chemins réseau (\\\\serveur\\…) ne sont pas autorisés.');
      }
      if (typeof b.qualiteEco === 'boolean') c.qualiteEco = b.qualiteEco;
      if ((b.rtmpBind === '127.0.0.1' || b.rtmpBind === '0.0.0.0') && b.rtmpBind !== c.rtmpBind) {
        if (!estLocal(req)) throw new ErreurHttp(403, 'Ce réglage se change depuis le PC de diffusion.');
        c.rtmpBind = b.rtmpBind;
      }
      if (typeof b.regieDistante === 'boolean' && b.regieDistante !== !!c.regieDistante) {
        if (!estLocal(req)) throw new ErreurHttp(403, 'Ce réglage se change depuis le PC de diffusion.');
        c.regieDistante = b.regieDistante;
      }
      for (const k of ['nomChaine', 'sousTitre']) if (typeof b[k] === 'string' && b[k].trim()) c[k] = b[k].trim().slice(0, 80);
      if (typeof b.lienYoutube === 'string') {
        const y = b.lienYoutube.trim();
        if (y && !/^https:\/\/(www\.|m\.)?youtube\.com\/(@[\w.-]{3,60}|channel\/UC[\w-]{22}|c\/[\w.-]{1,100}|user\/[\w.-]{1,100})\/?$/.test(y)) {
          throw new ErreurHttp(400, 'Lien YouTube invalide. Exemple : https://www.youtube.com/@RTMMoba');
        }
        c.lienYoutube = y.replace(/\/$/, '');
      }
      if (typeof b.adressePublique === 'string' && b.adressePublique.trim() !== (c.adressePublique || '')) {
        // Cette adresse est publiée aux téléphones : seulement depuis le PC de diffusion.
        if (!estLocal(req)) throw new ErreurHttp(403, 'L’adresse publique se change depuis le PC de diffusion.');
        if (b.adressePublique.trim() && !/^https:\/\//i.test(b.adressePublique.trim())) throw new ErreurHttp(400, 'L’adresse publique doit commencer par https://');
      }
      if (typeof b.adressePublique === 'string') {
        const a = b.adressePublique.trim();
        if (a && !/^https?:\/\/[^\s"'<>]+$/i.test(a)) throw new ErreurHttp(400, 'Adresse publique invalide (https://…).');
        c.adressePublique = a.slice(0, 200);
      }
      if (typeof b.ffmpeg === 'string') {
        const f = b.ffmpeg.trim();
        if (f && !/ffmpeg(\.exe)?$/i.test(f)) throw new ErreurHttp(400, 'Indiquez le chemin de ffmpeg.exe.');
        c.ffmpeg = f;
      }
      if (typeof b.grille === 'string' && b.grille.trim()) {
        if (!/\.json$/i.test(b.grille.trim())) throw new ErreurHttp(400, 'La grille doit être un fichier .json.');
        c.grille = b.grille.trim();
        grilleCache.t = 0;
      }
      config.save();
      journal('INFO', 'Réglages modifiés depuis la régie.');
      const relance = avant.qualiteEco !== c.qualiteEco || avant.rtmpBind !== c.rtmpBind || avant.ffmpeg !== c.ffmpeg;
      if (relance && !options.sansIngest) ingest.relancer({ rechercherFfmpeg: avant.ffmpeg !== c.ffmpeg });
      return { ok: true, relance };
    },
    'POST /api/regie/tunnel': (req, b) => {
      exigerRegie(req);
      const t = config.data.tunnel;
      if (typeof b.jeton === 'string' || b.effacerJeton === true) {
        if (!estLocal(req)) throw new ErreurHttp(403, 'Le jeton Cloudflare se colle depuis le PC de diffusion.');
        if (b.effacerJeton === true) t.jeton = '';
        else {
          // On accepte aussi la commande complète copiée depuis Cloudflare (« … --token eyJ… »).
          const brut = b.jeton.trim();
          const j = (/(?:--token\s+|^)(ey[A-Za-z0-9+/=_-]{40,})/.exec(brut) || [])[1] || brut;
          if (!jetonValide(j)) throw new ErreurHttp(400, 'Jeton Cloudflare invalide : copiez le jeton du tunnel (il commence par « ey »).');
          t.jeton = j;
        }
      }
      if (b.mode === 'rapide' || b.mode === 'fixe') t.mode = b.mode;
      if (typeof b.actif === 'boolean') t.actif = b.actif;
      if (t.actif && t.mode === 'fixe' && !jetonValide(t.jeton)) {
        t.actif = false;
        config.save();
        throw new ErreurHttp(400, 'Adresse fixe : collez d’abord le jeton du tunnel Cloudflare.');
      }
      config.save();
      if (tunnel) {
        if (!t.actif) tunnel.arreter();
        else if (tunnel.arrete) tunnel.demarrer();
        else tunnel.relancer();
      }
      journal('INFO', t.actif ? `Accès Internet activé (mode ${t.mode}).` : 'Accès Internet désactivé.');
      return { ok: true, tunnel: tunnel ? tunnel.resume() : null };
    },
    'POST /api/regie/nouvelle-cle': (req) => {
      exigerRegie(req);
      config.data.cle = 'rtm-' + crypto.randomBytes(9).toString('base64url');
      config.save();
      journal('INFO', 'Nouvelle clé de flux : mettez-la à jour dans vMix.');
      if (!options.sansIngest) ingest.relancer();
      return { cle: config.data.cle };
    },
    'POST /api/regie/maj': async (req, b) => {
      exigerRegie(req);
      if (b.installer === true) {
        if (!maj.disponible) throw new ErreurHttp(400, 'Aucune mise à jour prête.');
        maj.essayerAppliquer(true);
        return { maj: maj.resume() };
      }
      return { maj: await maj.verifier() };
    },
    'POST /api/regie/publication': (req, b) => {
      exigerRegie(req);
      if (!estLocal(req)) throw new ErreurHttp(403, 'Le jeton GitHub se colle depuis le PC de diffusion.');
      const j = typeof b.jeton === 'string' ? b.jeton.trim() : '';
      if (j && !/^github_pat_[A-Za-z0-9_]{20,255}$/.test(j)) throw new ErreurHttp(400, 'Jeton GitHub invalide : utilisez un jeton « fine-grained » (github_pat_…) limité au dépôt rtm-adresse.');
      config.data.publication.jeton = j;
      config.save();
      if (j) publication.publierBientot();
      return { ok: true, publication: publication.resume() };
    },
    // RTM Cast tourne sans fenêtre : on l'arrête depuis la régie (sur le PC seulement).
    'GET /api/regie/jaime': (req) => {
      exigerRegie(req);
      const parId = new Map(utilisateurs.data.liste.map((x) => [x.id, x]));
      const classement = Object.entries(jaime.data.par)
        .map(([id, n]) => ({ nom: parId.has(id) ? parId.get(id).nom : 'Compte supprimé', n }))
        .sort((a, b) => b.n - a.n).slice(0, 100);
      return { total: jaime.data.total || 0, personnes: Object.keys(jaime.data.par).length, classement, recents: flotJaime.slice(-40).reverse() };
    },
    'GET /api/regie/securite': (req) => { exigerRegie(req); return bouclier.resume(); },
    'POST /api/regie/debannir': (req, b) => {
      exigerRegie(req);
      if (typeof b.ip !== 'string' || b.ip.length > 64) throw new ErreurHttp(400, 'Adresse invalide.');
      bouclier.debannir(b.ip);
      journal('INFO', `Adresse débloquée depuis la régie : ${b.ip}`);
      return { ok: true };
    },
    'POST /api/regie/bannir': (req, b) => {
      exigerRegie(req);
      if (typeof b.ip !== 'string' || !/^[0-9a-fA-F:.]{3,64}$/.test(b.ip)) throw new ErreurHttp(400, 'Adresse invalide.');
      const h = Math.max(1, Math.min(24 * 365, Number(b.heures) || 24));
      bouclier.bannir(b.ip, 'bloquée à la main depuis la régie', h * 3600_000);
      return { ok: true };
    },
    'POST /api/regie/quitter': (req) => {
      exigerRegie(req);
      if (!estLocal(req)) throw new ErreurHttp(403, 'RTM Cast ne s\u2019arrête que depuis le PC de diffusion.');
      journal('INFO', 'Arrêt de RTM Cast demandé depuis la régie.');
      setTimeout(() => { fermer().finally(() => process.exit(4)); }, 300).unref?.();
      return { ok: true };
    },
    'POST /api/regie/relancer': (req) => {
      exigerRegie(req);
      journal('INFO', 'Relance de la réception demandée depuis la régie.');
      if (!options.sansIngest) ingest.relancer();
      return { ok: true };
    },
    'GET /api/regie/commentaires': (req) => { exigerRegie(req); return { commentaires: commentaires.data.liste.slice(-200).reverse() }; },
    'GET /api/regie/utilisateurs': (req) => {
      exigerRegie(req);
      return { utilisateurs: utilisateurs.data.liste.map((u) => ({ id: u.id, nom: u.nom, contact: u.contact, cree: u.cree, bloque: !!u.bloque })).reverse() };
    },
    'POST /api/regie/supprimer': (req, b) => {
      exigerRegie(req);
      const avant = commentaires.data.liste.length;
      // Supprimer un commentaire retire aussi ses réponses.
      commentaires.data.liste = commentaires.data.liste.filter((c) => c.id !== b.id && c.parent !== b.id);
      if (commentaires.data.liste.length !== avant) changerCommentaires();
      return { ok: true };
    },
    'POST /api/regie/bloquer': (req, b) => {
      exigerRegie(req);
      const u = utilisateurs.data.liste.find((x) => x.id === b.utilisateur);
      if (!u) throw new ErreurHttp(404, 'Utilisateur introuvable.');
      u.bloque = true;
      utilisateurs.save();
      const retires = new Set(commentaires.data.liste.filter((c) => c.u === u.id).map((c) => c.id));
      commentaires.data.liste = commentaires.data.liste.filter((c) => c.u !== u.id && !retires.has(c.parent));
      jaime.data.total = Math.max(0, (jaime.data.total || 0) - (jaime.data.par[u.id] || 0));
      delete jaime.data.par[u.id];
      jaime.saveBientot();
      changerCommentaires();
      journal('INFO', `Utilisateur bloqué : ${u.nom}`);
      return { ok: true };
    },
    'POST /api/regie/debloquer': (req, b) => {
      exigerRegie(req);
      const u = utilisateurs.data.liste.find((x) => x.id === b.utilisateur);
      if (!u) throw new ErreurHttp(404, 'Utilisateur introuvable.');
      u.bloque = false;
      utilisateurs.save();
      return { ok: true };
    },
    'POST /api/regie/infos': (req, b) => {
      exigerRegie(req);
      const titre = typeof b.titre === 'string' ? b.titre.trim().slice(0, 120) : '';
      const texte = typeof b.texte === 'string' ? b.texte.trim().slice(0, 2000) : '';
      if (!titre || !texte) throw new ErreurHttp(400, 'Titre et texte obligatoires.');
      infos.data.liste.unshift({ id: crypto.randomBytes(6).toString('hex'), titre, texte, t: Date.now() });
      infos.data.liste = infos.data.liste.slice(0, 100);
      infos.save();
      return [201, { ok: true }];
    },
    'POST /api/regie/infos/supprimer': (req, b) => {
      exigerRegie(req);
      infos.data.liste = infos.data.liste.filter((i) => i.id !== b.id);
      infos.save();
      return { ok: true };
    },
  };

  // ---------- routeur ----------
  function bloquer(res, status, texte) {
    res.writeHead(status, { ...SECURITE, 'Content-Type': 'text/plain; charset=utf-8', Connection: 'close', 'Cache-Control': 'no-store' });
    res.end(texte);
  }

  // Valeurs texte d'un corps JSON (pour y chercher des tentatives d'injection).
  function textesDe(o, n = 0, acc = []) {
    if (n > 3 || acc.length > 50) return acc;
    for (const v of Object.values(o || {})) {
      if (typeof v === 'string') acc.push(v.slice(0, 2000));
      else if (v && typeof v === 'object') textesDe(v, n + 1, acc);
    }
    return acc;
  }

  // Signale au bouclier une erreur révélatrice d'une attaque.
  function signalerErreur(req, p, status) {
    const ip = ipDe(req);
    const regieValide = (() => { try { exigerRegie(req); return true; } catch { return false; } })();
    if (status === 401 && p === '/api/regie/connexion') { if (!ipPrivee(ip)) bouclier.signaler(ip, 'regie_echec', 'mot de passe régie'); }
    // 403 en régie : seulement pour un visiteur SANS session régie (l'administrateur à distance n'est jamais puni)
    else if (status === 403 && p.startsWith('/api/regie/') && !regieValide && !ipPrivee(ip)) bouclier.signaler(ip, 'regie_echec', `accès refusé ${p}`);
    else if (status === 401 && p === '/api/connexion') bouclier.signaler(ip, 'connexion_echec');
    else if (status === 401 && (jetonDe(req) || lireCookie(req, COOKIE))) bouclier.signaler(ip, 'jeton_invalide', p);
    else if (status === 429 && p === '/api/regie/connexion') bouclier.signaler(ip, 'trop_de_requetes', p);
    else if (status === 413 || (status === 400 && p !== '/api/commentaires' && p !== '/api/inscription' && p !== '/api/moi/photo')) bouclier.signaler(ip, 'requete_invalide', p);
  }

  // Réseau local (régie sur un autre PC de la station) : jamais puni pour la régie.
  function ipPrivee(ip) {
    return /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.)/.test(ip) || /^f[cd][0-9a-f]{2}:/i.test(ip);
  }

  async function traiter(req, res) {
    const ip = ipDe(req);
    // 1. Adresse bloquée : rien ne passe, la connexion est coupée.
    if (bouclier.estBanni(ip)) return bloquer(res, 403, 'Accès bloqué.');
    // 2. Saturation (déni de service)
    if (bouclier.debitExcessif(ip, String(req.url || ''))) return bloquer(res, 429, 'Trop de requêtes.');
    // URL démesurée : refusée sans analyse
    if (String(req.url || '').length > 4096) { bouclier.signaler(ip, 'requete_invalide', 'URL démesurée'); return bloquer(res, 414, 'Adresse trop longue.'); }
    // 3. Requête d'attaque (chemins interdits, outils de piratage, injections)
    if (!bouclier.inspecter(ip, req)) return bloquer(res, 404, 'Introuvable.');
    const https = String(req.headers['cf-visitor'] || '').includes('https') || String(req.headers['x-forwarded-proto'] || '') === 'https';
    if (https) res.setHeader('Strict-Transport-Security', 'max-age=31536000');

    const url = new URL(req.url, 'http://local');
    const p = url.pathname;
    const route = routes[`${req.method} ${p}`];
    // Régie fermée à internet (par défaut) : elle ne s'ouvre que sur le PC de diffusion / le réseau local.
    if (route && p.startsWith('/api/regie/') && req.headers['cf-connecting-ip'] && !config.data.regieDistante) {
      bouclier.signaler(ip, 'regie_echec', `régie depuis internet ${p}`);
      return json(res, 404, { erreur: 'Introuvable.' });
    }
    // (anti-CSRF) Toute écriture doit être du JSON : une page piégée ne peut pas l'envoyer en douce.
    if (route && req.method === 'POST' && !/^application\/json\b/i.test(String(req.headers['content-type'] || ''))) {
      bouclier.signaler(ip, 'requete_invalide', `type ${p}`);
      return json(res, 415, { erreur: 'Format refusé.' });
    }
    if (route) {
      try {
        const corps = req.method === 'POST' ? await lireCorps(req, p === '/api/moi/photo' ? PHOTO_MAX : CORPS_MAX) : {};
        if (p !== '/api/moi/photo' && textesDe(corps).some((t) => /(<script|javascript:|onerror\s*=|union\s+select|\$\{jndi:)/i.test(t.slice(0, 2048)))) {
          // commentaire ou nom : souvent une maladresse -> peu de points ; ailleurs : injection
          bouclier.signaler(ip, /^\/api\/(commentaires|inscription)$/.test(p) ? 'contenu_suspect' : 'injection', `corps ${p}`);
          throw new ErreurHttp(400, 'Requête refusée.');
        }
        const r = await route(req, corps, url);
        if (Array.isArray(r)) {
          if (r[2]) for (const [k, v] of Object.entries(r[2])) res.setHeader(k, v);
          json(res, r[0], r[1]);
        } else json(res, 200, r);
      } catch (e) {
        if (e instanceof ErreurHttp) { signalerErreur(req, p, e.status); json(res, e.status, { erreur: e.message }); }
        else { journal('ERREUR', `${p} : ${e.message}`); json(res, 500, { erreur: 'Erreur interne.' }); }
      }
      return;
    }
    if (p.startsWith('/api/')) { bouclier.signaler(ip, 'introuvable', p); return json(res, 404, { erreur: 'Introuvable.' }); }
    if (req.method !== 'GET' && req.method !== 'HEAD') { bouclier.signaler(ip, 'requete_invalide', `méthode ${req.method}`); return envoyer(res, 405, 'Méthode non autorisée.'); }

    // Contenu réservé aux spectateurs inscrits : le direct et les photos de profil.
    if ((p === '/regie' || p.startsWith('/regie/')) && req.headers['cf-connecting-ip'] && !config.data.regieDistante) {
      bouclier.signaler(ip, 'introuvable', p);
      return envoyer(res, 404, 'Introuvable.');
    }
    if ((p.startsWith('/hls/') || p.startsWith('/photos/')) && !utilisateurConnecte(req)) {
      return envoyer(res, 401, 'Connectez-vous pour regarder RTM.', { 'Cache-Control': 'no-store' });
    }
    if (p.startsWith('/photos/')) {
      const m = /^\/photos\/([0-9a-f]{16})\.jpg$/.exec(p);
      if (!m) return envoyer(res, 404, 'Introuvable.');
      return servirFichier(res, dossierPhotos, `${m[1]}.jpg`, { 'Cache-Control': 'private, max-age=86400' });
    }
    if (p.startsWith('/hls/')) {
      const f = p.slice(5);
      const cache = f.endsWith('.m3u8') ? 'no-cache, no-store' : 'private, max-age=60';
      return servirFichier(res, hlsDir, f, { 'Cache-Control': cache });
    }
    if (p === '/' || p === '/index.html') return servirFichier(res, path.join(PUBLIC, 'app'), 'index.html', { 'Cache-Control': 'no-cache' });
    if (p === '/sw.js') return servirFichier(res, path.join(PUBLIC, 'app'), 'sw.js', { 'Cache-Control': 'no-cache' });
    if (p === '/manifest.webmanifest') return servirFichier(res, path.join(PUBLIC, 'app'), 'manifest.webmanifest', { 'Cache-Control': 'no-cache' });
    if (p === '/regie' || p === '/regie/') return servirFichier(res, path.join(PUBLIC, 'regie'), 'index.html', { 'Cache-Control': 'no-cache' });
    if (p.startsWith('/regie/')) return servirFichier(res, path.join(PUBLIC, 'regie'), p.slice(7), { 'Cache-Control': 'no-cache' });
    if (p.startsWith('/app/')) return servirFichier(res, path.join(PUBLIC, 'app'), p.slice(5), { 'Cache-Control': 'no-cache' });
    if (p === '/telechargement/RTM-Direct.apk') {
      return servirFichier(res, path.join(PUBLIC, 'telechargement'), 'RTM-Direct.apk', {
        'Cache-Control': 'no-cache', 'Content-Disposition': 'attachment; filename="RTM-Direct.apk"',
      });
    }
    if (p === '/incrustation' || p === '/incrustation/') {
      try { verifierCleIncrustation(req, url); } catch { return envoyer(res, 403, 'Accès refusé.'); }
      return servirFichier(res, path.join(PUBLIC, 'incrustation'), 'index.html', { 'Cache-Control': 'no-store' });
    }
    if (/^\/incrustation\/incrustation\.(js|css)$/.test(p)) return servirFichier(res, path.join(PUBLIC, 'incrustation'), p.slice(14), { 'Cache-Control': 'no-cache' });
    if (p.startsWith('/vendor/')) return servirFichier(res, path.join(PUBLIC, 'vendor'), p.slice(8), { 'Cache-Control': 'public, max-age=86400' });
    if (!/^\/(favicon\.ico|robots\.txt|apple-touch-icon[\w-]*\.png)$/.test(p)) bouclier.signaler(ip, 'introuvable', p);
    return envoyer(res, 404, 'Introuvable.');
  }

  const serveur = http.createServer((req, res) => {
    traiter(req, res).catch(() => { try { json(res, 500, { erreur: 'Erreur interne.' }); } catch { /* déjà envoyé */ } });
  });
  serveur.requestTimeout = 30_000;
  serveur.headersTimeout = 15_000;
  serveur.maxConnections = 5000;     // au-delà, les nouvelles connexions sont refusées
  serveur.keepAliveTimeout = 10_000;

  const port = options.port ?? config.data.port;
  const host = options.host ?? '0.0.0.0';
  await new Promise((ok, ko) => { serveur.once('error', ko); serveur.listen(port, host, ok); });
  const portReel = serveur.address().port;
  portEcoute = portReel;
  let bascule = false;
  if (!(options.sansInstallation ?? options.sansIngest)) {
    installation.mettreEnPlace({ racine: RACINE, version: VERSION, config, journal });
    if (installation.doitBasculer(RACINE)) {
      bascule = true;
      journal('INFO', 'Passage au lancement invisible : RTM Cast redémarre sans fenêtre dans quelques secondes.');
      installation.lancerInvisibleBientot(RACINE);
    }
  }
  // Après l'ouverture du port : une 2e instance ne touche jamais au ffmpeg de la 1re.
  if (!options.sansIngest && !bascule) ingest.demarrer();
  tunnel = new Tunnel({ config, racineAppli: RACINE, journal, port: portReel });
  // L'adresse du direct est publiée sur la page d'installation quand elle change.
  publication = new Publication({ config, journal, adresse: () => lienPublic() });
  tunnel.on('adresse', () => publication.publierBientot());
  maj = new MiseAJour({
    config, racine: RACINE, version: VERSION, dataDir, journal, estEnDirect,
    redemarrer: () => { fermer().finally(() => process.exit(3)); },
  });
  if (bascule) setTimeout(() => { fermer().finally(() => process.exit(2)); }, 500).unref?.();
  else if (!(options.sansMaj ?? options.sansIngest)) { maj.demarrer(); publication.publierBientot(); }
  if (config.data.tunnel.actif && !(options.sansTunnel ?? options.sansIngest)) tunnel.demarrer();
  journal('INFO', `RTM Cast prêt — appli : http://localhost:${portReel}  ·  régie : http://localhost:${portReel}/regie`);

  async function fermer() {
    clearInterval(minuteurPurge);
    if (maj) maj.arreter();
    ingest.arreter();
    tunnel.arreter();
    for (const s of [commentaires, jaime, sessions, utilisateurs, infos]) { try { s.save(); } catch { /* ignore */ } }
    bouclier.enregistrer();
    await new Promise((ok) => { serveur.closeAllConnections?.(); serveur.close(() => ok()); });
  }

  // Mise à jour validée après 60 s de fonctionnement (sinon le lanceur restaure l'ancienne version).
  const minuteurValidation = setTimeout(() => {
    try { fs.rmSync(path.join(dataDir, 'maj', 'a-valider.json'), { force: true }); } catch { /* ignore */ }
  }, options.delaiValidation ?? 60_000);
  minuteurValidation.unref?.();

  return { port: portReel, hlsDir, dataDir, fermer, ingest, tunnel };
}

function principal() {
  return demarrer().then((app) => {
    const arret = async () => { await app.fermer(); process.exit(0); };
    process.on('SIGINT', arret);
    process.on('SIGTERM', arret);
    // Sous Windows, ffmpeg survit à un plantage de Node : on le tue toujours.
    process.on('exit', () => { app.ingest.tuer(); app.tunnel.arreter(); });
    process.on('uncaughtException', (e) => {
      console.error(`Erreur inattendue : ${e.stack || e}`);
      app.ingest.tuer();
      app.tunnel.arreter();
      process.exit(1); // LANCER_RTM_CAST.bat relance RTM Cast
    });
    process.on('unhandledRejection', (e) => console.error(`Promesse rejetée : ${e && e.stack || e}`));
  }).catch((e) => {
    console.error(e.code === 'EADDRINUSE'
      ? `Le port ${e.port || ''} est déjà utilisé : RTM Cast est peut-être déjà ouvert (ou changez "port" dans config.json).`
      : `Démarrage impossible : ${e.message}`);
    process.exit(e.code === 'EADDRINUSE' ? 2 : 1);
  });
}

module.exports = { demarrer, principal };

if (require.main === module) principal();
