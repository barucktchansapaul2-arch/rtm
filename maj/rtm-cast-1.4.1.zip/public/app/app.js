/* RTM Direct — appli mobile de Radio Télévision Moba (web, PWA et APK Android). */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const stockage = {
    lire(k) { try { return localStorage.getItem(k); } catch { return null; } },
    ecrire(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch { /* privé */ } },
  };
  const android = window.RTMAndroid || null;     // pont natif de l'APK
  const estIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const estAndroid = /Android/i.test(navigator.userAgent);
  const installee = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;

  // ---------- état ----------
  let jeton = stockage.lire('rtm.jeton');
  let moi = null;
  let enDirect = false;
  let versionCom = null;
  let commentaires = [];
  let modeCompte = stockage.lire('rtm.dejaInscrit') ? 'connexion' : 'inscription';
  let qualite = stockage.lire('rtm.eco') === '1' ? 'eco' : 'auto';
  let hls = null;
  let veutRegarder = false;
  let ecoDispo = true;
  let sessionIngest = 0;
  let lienPartage = '';
  let lienYoutube = '';
  let lienOfficiel = '';
  let programmeActuel = 'RTM en direct';
  let minuteurs = [];

  const idAppareil = (() => {
    let id = stockage.lire('rtm.appareil');
    if (!id) {
      const a = new Uint8Array(12);
      crypto.getRandomValues(a);
      id = Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
      stockage.ecrire('rtm.appareil', id);
    }
    return id;
  })();

  // ---------- outils ----------
  async function api(methode, chemin, corps) {
    const entetes = {};
    if (corps !== undefined) entetes['Content-Type'] = 'application/json';
    if (jeton) entetes.Authorization = 'Bearer ' + jeton;
    const r = await fetch(chemin, { method: methode, headers: entetes, body: corps === undefined ? undefined : JSON.stringify(corps), cache: 'no-store', credentials: 'same-origin' });
    let d = {};
    try { d = await r.json(); } catch { /* vide */ }
    if (!r.ok) {
      if (r.status === 401 && jeton && chemin !== '/api/connexion') sessionPerdue();
      const e = new Error(d.erreur || 'Connexion impossible. Vérifiez votre internet.');
      e.status = r.status;
      throw e;
    }
    return d;
  }

  function toast(texte) {
    const t = $('toast');
    t.textContent = texte;
    t.hidden = false;
    clearTimeout(toast.m);
    toast.m = setTimeout(() => { t.hidden = true; }, 3200);
  }

  const initiales = (nom) => String(nom || '?').trim().split(/\s+/).slice(0, 2).map((m) => m[0]).join('') || '?';

  function compact(n) {
    if (n < 1000) return String(n);
    if (n < 1e6) return (n / 1000).toFixed(n < 10000 ? 1 : 0).replace('.', ',').replace(',0', '') + ' k';
    return (n / 1e6).toFixed(1).replace('.', ',').replace(',0', '') + ' M';
  }

  function ilYa(t) {
    const s = Math.max(0, Math.round((Date.now() - t) / 1000));
    if (s < 60) return 'à l\'instant';
    const m = Math.round(s / 60);
    if (m < 60) return `il y a ${m} min`;
    const h = Math.round(m / 60);
    if (h < 24) return `il y a ${h} h`;
    return new Date(t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  }

  // Point vert sur les avatars des personnes en ligne.
  let enLigne = new Set();
  function marquerEnLigne(racine) {
    for (const a of (racine || document).querySelectorAll('.avatar[data-u]')) {
      a.classList.toggle('en-ligne', enLigne.has(a.dataset.u) || (moi && a.dataset.u === moi.id));
    }
  }
  async function chargerEnLigne() {
    try {
      const d = await api('GET', '/api/en-ligne');
      enLigne = new Set(d.ids);
      marquerEnLigne();
    } catch { /* plus tard */ }
  }

  // Avatar : photo si elle existe, sinon initiales (seules les photos du serveur RTM).
  function remplirAvatar(el, nom, photo, idUtilisateur) {
    if (idUtilisateur) el.dataset.u = idUtilisateur;
    if (photo && !/^\/photos\/[0-9a-f]{16}\.jpg\?v=\d+$/.test(photo)) photo = null;
    el.textContent = initiales(nom);
    el.classList.toggle('photo', !!photo);
    el.style.backgroundImage = photo ? `url("${String(photo).replace(/["\\]/g, '')}")` : '';
  }

  // ---------- COMPTE OBLIGATOIRE ----------
  function afficherCompte() {
    document.body.classList.add('sans-compte');
    basculerMode(modeCompte);
    window.scrollTo(0, 0);
  }

  function entrer() {
    document.body.classList.remove('sans-compte');
    majMoi();
    allerA('direct');
    demarrerBoucles();
  }

  function sessionPerdue() {
    jeton = null;
    moi = null;
    clearTimeout(minuteurJaime);
    tapesEnAttente = 0;
    commentaires = [];
    versionCom = null;
    ouvertes.clear();
    $('liste-commentaires').textContent = '';
    stockage.ecrire('rtm.jeton', null);
    arreterBoucles();
    arreterLecture();
    veutRegarder = false;
    fermerFeuilles();
    modeCompte = 'connexion';
    afficherCompte();
  }

  function basculerMode(mode) {
    modeCompte = mode;
    const ins = mode === 'inscription';
    $('titre-compte').textContent = ins ? 'Créer un compte' : 'Se connecter';
    $('texte-compte').textContent = ins
      ? 'Créez votre compte gratuit pour regarder RTM en direct, aimer, commenter et partager.'
      : 'Heureux de vous revoir sur RTM Direct.';
    $('groupe-nom').hidden = !ins;
    $('groupe-conditions').hidden = !ins;
    $('btn-compte').textContent = ins ? 'Créer mon compte' : 'Me connecter';
    $('btn-bascule').textContent = ins ? 'J\'ai déjà un compte' : 'Créer un nouveau compte';
    $('champ-mdp').autocomplete = ins ? 'new-password' : 'current-password';
    $('erreur-compte').textContent = '';
  }
  $('btn-bascule').addEventListener('click', () => basculerMode(modeCompte === 'inscription' ? 'connexion' : 'inscription'));

  $('form-compte').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const err = $('erreur-compte');
    err.textContent = '';
    const contact = $('champ-contact').value.trim();
    const motDePasse = $('champ-mdp').value;
    const ins = modeCompte === 'inscription';
    if (ins && $('champ-nom').value.trim().length < 2) { err.textContent = 'Indiquez votre nom.'; return; }
    if (!contact) { err.textContent = 'Indiquez votre téléphone ou votre e-mail.'; return; }
    if (motDePasse.length < 8) { err.textContent = 'Le mot de passe doit faire au moins 8 caractères.'; return; }
    if (ins && !$('case-conditions').checked) { err.textContent = 'Acceptez les conditions d\'utilisation.'; return; }
    const btn = $('btn-compte');
    btn.disabled = true;
    try {
      const r = ins
        ? await api('POST', '/api/inscription', { nom: $('champ-nom').value, contact, motDePasse, conditions: true })
        : await api('POST', '/api/connexion', { contact, motDePasse });
      jeton = r.jeton;
      moi = r.utilisateur;
      stockage.ecrire('rtm.jeton', jeton);
      stockage.ecrire('rtm.dejaInscrit', '1');
      $('champ-mdp').value = '';
      toast(ins ? `Bienvenue sur RTM Direct, ${moi.nom} !` : `Bon retour, ${moi.nom} !`);
      entrer();
    } catch (e) {
      err.textContent = e.message;
    } finally {
      btn.disabled = false;
    }
  });

  function majMoi() {
    const nom = moi ? moi.nom : 'Moi';
    const photo = moi ? moi.photo : null;
    for (const id of ['avatar-saisie', 'avatar-plus', 'avatar-profil']) remplirAvatar($(id), nom, photo, moi && moi.id);
    marquerEnLigne();
    $('nom-plus').textContent = moi ? moi.nom : 'Mon compte';
    $('nom-profil').textContent = moi ? moi.nom : '';
    const stats = moi ? 'Membre de RTM Direct' : '';
    $('stats-plus').textContent = stats;
    $('stats-profil').textContent = stats;
    $('btn-retirer-photo').hidden = !(moi && moi.photo);

  }

  $('btn-deconnexion').addEventListener('click', async () => {
    try { await api('POST', '/api/deconnexion', {}); } catch { /* hors ligne */ }
    sessionPerdue();
    toast('Vous êtes déconnecté.');
  });

  // ---------- navigation ----------
  const PAGES = ['direct', 'infos', 'plus'];
  function allerA(page) {
    for (const p of PAGES) $('page-' + p).hidden = p !== page;
    for (const b of document.querySelectorAll('.barre button')) b.classList.toggle('actif', b.dataset.page === page);
    if (page === 'infos') chargerInfos();
    window.scrollTo(0, 0);
  }
  for (const b of document.querySelectorAll('.barre button')) b.addEventListener('click', () => allerA(b.dataset.page));

  // ---------- feuilles (commentaires, partage, profil) ----------
  function ouvrirFeuille(id) {
    fermerFeuilles();
    $('voile-feuille').hidden = false;
    $(id).hidden = false;
  }
  function fermerFeuilles() {
    $('voile-feuille').hidden = true;
    for (const f of document.querySelectorAll('.feuille')) f.hidden = true;
    annulerReponse();
  }
  $('voile-feuille').addEventListener('click', fermerFeuilles);
  for (const b of document.querySelectorAll('[data-fermer]')) b.addEventListener('click', fermerFeuilles);

  // ---------- lecteur ----------
  const video = $('video');
  const lecteur = $('lecteur');
  const SOURCE = { auto: '/hls/master.m3u8', hd: '/hls/hd.m3u8', eco: '/hls/eco.m3u8' };
  const NOMS_QUALITE = { auto: 'Auto', hd: 'HD', eco: 'Éco' };

  function messageLecteur(texte) {
    const m = $('msg-lecteur');
    m.textContent = texte || '';
    m.hidden = !texte;
  }

  function arreterLecture() {
    if (hls) { hls.destroy(); hls = null; }
    video.removeAttribute('src');
    try { video.load(); } catch { /* ignore */ }
    lecteur.classList.remove('lecture');
  }

  function lancerLecture() {
    veutRegarder = true;
    if (!enDirect) {
      messageLecteur('RTM n\'est pas à l\'antenne pour le moment. La lecture reprendra toute seule.');
      return;
    }
    messageLecteur('');
    arreterLecture();
    const src = SOURCE[qualite === 'eco' && !ecoDispo ? 'auto' : qualite];
    if (window.Hls && window.Hls.isSupported()) {
      let reparations = 0;
      hls = new window.Hls({
        liveSyncDurationCount: 3, maxBufferLength: 20, backBufferLength: 10,
        xhrSetup: (xhr) => { if (jeton) xhr.setRequestHeader('Authorization', 'Bearer ' + jeton); },
      });
      hls.loadSource(src);
      hls.attachMedia(video);
      hls.on(window.Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); });
      hls.on(window.Hls.Events.ERROR, (_, d) => {
        if (!d.fatal) return;
        if (d.type === window.Hls.ErrorTypes.MEDIA_ERROR && reparations < 2) {
          if (reparations++ === 1) hls.swapAudioCodec();
          hls.recoverMediaError();
          return;
        }
        arreterLecture();
        messageLecteur('Connexion au direct perdue… nouvel essai.');
        setTimeout(() => { if (veutRegarder) lancerLecture(); }, 5000);
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = src; // iPhone : le cookie de session accompagne la lecture
      video.play().catch(() => {});
    } else {
      messageLecteur('Ce navigateur ne sait pas lire le direct. Utilisez Chrome ou Safari.');
      return;
    }
    lecteur.classList.add('lecture');
  }

  $('btn-lecture').addEventListener('click', lancerLecture);
  video.addEventListener('ended', () => {
    if (!veutRegarder) return;
    arreterLecture();
    messageLecteur('Le direct reprend dans un instant…');
    setTimeout(() => { if (veutRegarder && enDirect) lancerLecture(); }, 3000);
  });
  video.addEventListener('error', () => {
    if (!veutRegarder || hls) return;
    arreterLecture();
    setTimeout(() => { if (veutRegarder) lancerLecture(); }, 5000);
  });
  // Pas de menu « Enregistrer la vidéo » ni d'image incrustée.
  lecteur.addEventListener('contextmenu', (e) => e.preventDefault());

  $('btn-son').addEventListener('click', (e) => {
    e.stopPropagation();
    video.muted = !video.muted;
    $('btn-son').classList.toggle('muet', video.muted);
  });
  $('btn-qualite').textContent = NOMS_QUALITE[qualite];
  $('btn-qualite').addEventListener('click', (e) => {
    e.stopPropagation();
    qualite = qualite === 'auto' ? 'hd' : qualite === 'hd' ? 'eco' : 'auto';
    $('btn-qualite').textContent = NOMS_QUALITE[qualite];
    toast('Qualité : ' + { auto: 'automatique', hd: 'HD', eco: 'Économie (moins de données)' }[qualite]);
    if (veutRegarder) lancerLecture();
  });
  $('btn-plein-ecran').addEventListener('click', (e) => {
    e.stopPropagation();
    if (document.fullscreenElement) { document.exitFullscreen(); return; }
    if (lecteur.requestFullscreen) lecteur.requestFullscreen().then(() => screen.orientation?.lock?.('landscape').catch(() => {})).catch(() => {});
    else if (video.webkitEnterFullscreen) video.webkitEnterFullscreen();
  });

  // ---------- J'AIME façon TikTok ----------
  let tapesEnAttente = 0;
  let minuteurJaime = null;

  function coeurVolant(x, y, gros) {
    const ns = 'http://www.w3.org/2000/svg';
    const s = document.createElementNS(ns, 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    s.setAttribute('class', 'coeur-vol' + (gros ? ' gros' : ''));
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('d', 'M12 21s-7.8-4.8-9.6-9.7C1.1 7.8 3.4 4.2 7 4.2c2.1 0 3.7 1.1 5 2.9 1.3-1.8 2.9-2.9 5-2.9 3.6 0 5.9 3.6 4.6 7.1C19.8 16.2 12 21 12 21z');
    s.append(p);
    s.style.left = x + 'px';
    s.style.top = y + 'px';
    s.style.setProperty('--dx', `${Math.round((Math.random() - 0.5) * 70)}px`);
    s.style.setProperty('--rot', `${Math.round((Math.random() - 0.5) * 40)}deg`);
    document.body.append(s);
    setTimeout(() => s.remove(), 1100);
  }

  function aimer(x, y, gros) {
    if (!moi) return;
    if (moi.bloque) { toast('Votre compte est bloqué.'); return; }
    tapesEnAttente += 1;
    const c = $('btn-jaime').querySelector('.coeur');
    c.classList.add('actif');
    c.classList.remove('pop');
    void c.offsetWidth;
    c.classList.add('pop');
    coeurVolant(x, y, gros);
    if (navigator.vibrate) { try { navigator.vibrate(12); } catch { /* */ } }
    clearTimeout(minuteurJaime);
    minuteurJaime = setTimeout(envoyerJaime, 700);
  }

  async function envoyerJaime() {
    while (tapesEnAttente > 0) {
      const n = Math.min(50, tapesEnAttente);
      tapesEnAttente -= n;
      try {
        const r = await api('POST', '/api/jaime', { n });
        if (r.limite) { tapesEnAttente = 0; toast('Doucement ! Réessayez dans quelques secondes.'); }
      } catch (e) { tapesEnAttente = 0; toast(e.message); }
    }
  }

  $('btn-jaime').addEventListener('click', () => {
    const r = $('btn-jaime').querySelector('.rond').getBoundingClientRect();
    aimer(r.left + r.width / 2, r.top, false);
  });

  // Une tape au milieu de la vidéo = pause / reprise ; deux tapes rapides = J'aime (comme TikTok)
  const ICONE_PAUSE = '<svg viewBox="0 0 24 24"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="#fff"/></svg>';
  const ICONE_LECTURE = '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l10.5-6.5z" fill="#fff"/></svg>';
  let derniereTape = 0;
  let minuteurTape = null;
  let enPauseDepuis = 0;

  function icone(svg, persistante) {
    const el = $('pause-icone');
    el.innerHTML = svg; // contenu fixe (pas de donnée venue d'internet)
    el.className = 'pause-icone ' + (persistante ? 'visible' : 'eclair');
  }

  function basculerPause() {
    if (!lecteur.classList.contains('lecture')) return;
    if (video.paused) {
      // Reprise : après une longue pause, on revient au direct (pas à l'ancienne image)
      if (enPauseDepuis && Date.now() - enPauseDepuis > 20_000) {
        if (hls && hls.liveSyncPosition) video.currentTime = hls.liveSyncPosition;
        else if (video.seekable && video.seekable.length) video.currentTime = Math.max(0, video.seekable.end(video.seekable.length - 1) - 3);
      }
      enPauseDepuis = 0;
      video.play().catch(() => {});
      icone(ICONE_LECTURE, false);
    } else {
      video.pause();
      enPauseDepuis = Date.now();
      icone(ICONE_PAUSE, true);
    }
  }

  lecteur.addEventListener('click', (e) => {
    if (e.target.closest('button')) return;
    const t = Date.now();
    if (t - derniereTape < 320) {
      clearTimeout(minuteurTape);
      minuteurTape = null;
      derniereTape = 0;
      aimer(e.clientX, e.clientY, true);
      return;
    }
    derniereTape = t;
    clearTimeout(minuteurTape);
    minuteurTape = setTimeout(() => { minuteurTape = null; basculerPause(); }, 330);
  });
  video.addEventListener('playing', () => { if (!video.paused) $('pause-icone').className = 'pause-icone'; });

  // ---------- COMMENTAIRES (avec réponses) ----------
  let reponseA = null;
  const ouvertes = new Set();

  function annulerReponse() {
    reponseA = null;
    $('reponse-a').hidden = true;
    $('champ-commentaire').placeholder = 'Ajouter un commentaire…';
  }
  $('annuler-reponse').addEventListener('click', annulerReponse);

  function repondre(c) {
    reponseA = c;
    $('reponse-nom').textContent = c.auteur;
    $('reponse-a').hidden = false;
    $('champ-commentaire').placeholder = `Répondre à ${c.auteur}…`;
    $('champ-commentaire').focus();
  }

  function ligneCommentaire(c, petit) {
    const li = document.createElement('li');
    li.className = 'com';
    const av = document.createElement('span');
    av.className = 'avatar';
    remplirAvatar(av, c.auteur, c.photo, c.utilisateur);
    const corps = document.createElement('div');
    corps.className = 'corps';
    const nom = document.createElement('div');
    nom.className = 'nom';
    nom.textContent = c.auteur;
    const p = document.createElement('p');
    p.textContent = c.texte;
    const meta = document.createElement('div');
    meta.className = 'meta';
    const quand = document.createElement('span');
    quand.textContent = ilYa(c.t);
    const rep = document.createElement('button');
    rep.type = 'button';
    rep.textContent = 'Répondre';
    rep.addEventListener('click', () => repondre(c));
    meta.append(quand, rep);
    corps.append(nom, p, meta);
    li.append(av, corps);
    if (petit) li.classList.add('petit');
    return li;
  }

  function afficherCommentaires() {
    const ul = $('liste-commentaires');
    ul.textContent = '';
    const principaux = commentaires.filter((c) => !c.parent).reverse();
    const reponses = new Map();
    for (const c of commentaires) if (c.parent) { if (!reponses.has(c.parent)) reponses.set(c.parent, []); reponses.get(c.parent).push(c); }
    for (const c of principaux) {
      ul.append(ligneCommentaire(c, false));
      const reps = reponses.get(c.id) || [];
      if (!reps.length) continue;
      const bouton = document.createElement('button');
      bouton.type = 'button';
      bouton.className = 'voir-reponses';
      const sousListe = document.createElement('ul');
      sousListe.className = 'reponses';
      for (const r of reps) sousListe.append(ligneCommentaire(r, true));
      const maj = () => {
        const ouvert = ouvertes.has(c.id);
        sousListe.hidden = !ouvert;
        bouton.textContent = ouvert ? '— Masquer les réponses' : `— Voir ${reps.length} réponse${reps.length > 1 ? 's' : ''}`;
      };
      bouton.addEventListener('click', () => { if (ouvertes.has(c.id)) ouvertes.delete(c.id); else ouvertes.add(c.id); maj(); });
      maj();
      const li = document.createElement('li');
      li.append(bouton, sousListe);
      ul.append(li);
    }
    $('aucun-commentaire').hidden = principaux.length > 0;
    marquerEnLigne(ul);
  }

  async function chargerCommentaires() {
    try {
      const d = await api('GET', '/api/commentaires' + (versionCom !== null ? '?v=' + versionCom : ''));
      if (d.inchange) return;
      versionCom = d.version;
      commentaires = d.commentaires;
      $('nb-commentaires').textContent = compact(d.total);
      $('nb-commentaires-2').textContent = d.total;
      if (!$('feuille-commentaires').hidden) afficherCommentaires();
    } catch { /* réessai plus tard */ }
  }

  $('btn-commenter').addEventListener('click', () => {
    ouvrirFeuille('feuille-commentaires');
    afficherCommentaires();
    chargerCommentaires();
  });

  $('form-commentaire').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const champ = $('champ-commentaire');
    const texte = champ.value.trim();
    $('erreur-commentaire').textContent = '';
    if (!texte) return;
    try {
      const corps = { texte };
      if (reponseA) corps.parent = reponseA.id;
      const r = await api('POST', '/api/commentaires', corps);
      champ.value = '';
      if (r.commentaire.parent) ouvertes.add(r.commentaire.parent);
      annulerReponse();
      versionCom = null;
      await chargerCommentaires();
      afficherCommentaires();
    } catch (e) {
      $('erreur-commentaire').textContent = e.message;
    }
  });

  // ---------- PARTAGE (liens + la vidéo du direct) ----------
  function lienAPartager() {
    return lienOfficiel || lienPartage || location.origin + '/';
  }

  function texteAPartager() {
    return `📺 Je regarde « ${programmeActuel} » en direct sur RTM — Radio Télévision Moba ! Regardez avec moi :`;
  }

  function preparerPartage() {
    const lien = lienAPartager();
    const texte = texteAPartager();
    const e = encodeURIComponent;
    const liens = {
      whatsapp: `https://wa.me/?text=${e(texte + ' ' + lien)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${e(lien)}`,
      telegram: `https://t.me/share/url?url=${e(lien)}&text=${e(texte)}`,
      x: `https://twitter.com/intent/tweet?text=${e(texte)}&url=${e(lien)}`,
      sms: `sms:?&body=${e(texte + ' ' + lien)}`,
      email: `mailto:?subject=${e('RTM en direct')}&body=${e(texte + '\n' + lien)}`,
    };
    for (const a of document.querySelectorAll('[data-reseau]')) a.href = liens[a.dataset.reseau];
    $('texte-partage').textContent = `« ${programmeActuel} » — partagez le direct avec vos proches.`;
    $('lien-partage').textContent = lien;
  }

  $('btn-partager').addEventListener('click', () => { preparerPartage(); ouvrirFeuille('feuille-partage'); });
  $('partage-copier').addEventListener('click', async () => {
    const lien = lienAPartager();
    try { await navigator.clipboard.writeText(texteAPartager() + ' ' + lien); toast('Lien copié ! Collez-le dans vos discussions.'); }
    catch { toast(lien); }
  });
  $('partage-autres').addEventListener('click', async () => {
    const lien = lienAPartager();
    if (android) { try { android.partager('RTM Direct', texteAPartager(), lien); return; } catch { /* repli */ } }
    try { if (navigator.share) { await navigator.share({ title: 'RTM Direct', text: texteAPartager(), url: lien }); return; } }
    catch (e) { if (e && e.name === 'AbortError') return; }
    try { await navigator.clipboard.writeText(lien); toast('Lien copié : ' + lien); } catch { toast(lien); }
  });

  // ---------- PROFIL et PHOTO ----------
  function ouvrirProfil() { majMoi(); $('erreur-photo').textContent = ''; ouvrirFeuille('feuille-profil'); }
  $('btn-abonner').addEventListener('click', () => {
    if (!lienYoutube) { toast('La chaîne YouTube de RTM arrive bientôt.'); return; }
    const u = new URL(lienYoutube);
    u.searchParams.set('sub_confirmation', '1'); // YouTube propose directement « S'abonner »
    window.open(u.toString(), '_blank', 'noopener');
  });
  $('btn-ouvrir-profil').addEventListener('click', ouvrirProfil);
  $('avatar-plus').addEventListener('click', ouvrirProfil);
  $('avatar-profil').addEventListener('click', () => $('fichier-photo').click());

  // Recadre en carré 320 px et compresse en JPEG (< 160 Ko) avant l'envoi.
  function preparerPhoto(fichier) {
    return new Promise((ok, ko) => {
      const url = URL.createObjectURL(fichier);
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = 320; c.height = 320;
        const cote = Math.min(img.naturalWidth, img.naturalHeight);
        c.getContext('2d').drawImage(img, (img.naturalWidth - cote) / 2, (img.naturalHeight - cote) / 2, cote, cote, 0, 0, 320, 320);
        URL.revokeObjectURL(url);
        let q = 0.85;
        let data = c.toDataURL('image/jpeg', q);
        while (data.length > 200_000 && q > 0.4) { q -= 0.15; data = c.toDataURL('image/jpeg', q); }
        ok(data);
      };
      img.onerror = () => { URL.revokeObjectURL(url); ko(new Error('Image illisible. Choisissez une photo JPG ou PNG.')); };
      img.src = url;
    });
  }

  $('fichier-photo').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!f) return;
    $('erreur-photo').textContent = '';
    try {
      const image = await preparerPhoto(f);
      const r = await api('POST', '/api/moi/photo', { image });
      moi = r.utilisateur;
      majMoi();
      versionCom = null;
      chargerCommentaires();
      toast('Photo de profil enregistrée.');
    } catch (err) { $('erreur-photo').textContent = err.message; }
  });
  $('btn-retirer-photo').addEventListener('click', async () => {
    try {
      const r = await api('POST', '/api/moi/photo', { supprimer: true });
      moi = r.utilisateur;
      majMoi();
      versionCom = null;
      chargerCommentaires();
    } catch (err) { $('erreur-photo').textContent = err.message; }
  });

  // ---------- état de l'antenne ----------
  async function rafraichirEtat() {
    try {
      const e = await api('GET', '/api/etat');
      // Entré hors ligne : on récupère le vrai profil au retour du réseau.
      if (moi && moi.horsLigne) {
        try { moi = (await api('GET', '/api/moi')).utilisateur; majMoi(); } catch { /* plus tard */ }
      }
      $('nom-chaine').textContent = e.nomChaine || 'RTM Direct';
      $('sous-titre').textContent = e.sousTitre || '';
      $('nb-commentaires').textContent = compact(e.commentaires);
      programmeActuel = e.maintenant ? e.maintenant.programme : 'RTM en direct';
      $('titre-programme').textContent = programmeActuel;
      $('bloc-ensuite').hidden = !e.ensuite;
      if (e.ensuite) $('texte-ensuite').textContent = `${e.ensuite.programme} · ${e.ensuite.debut}`;
      lienOfficiel = /^https:\/\//.test(e.lienOfficiel || '') ? e.lienOfficiel : '';
      lienPartage = /^https:\/\//.test(e.lienPartage || '') ? e.lienPartage.replace(/\/+$/, '') + '/' : '';
      ecoDispo = e.eco !== false;
      lienYoutube = /^https:\/\/(www\.|m\.)?youtube\.com\/[\w@./-]+$/.test(e.youtube || '') ? e.youtube : '';
      const avant = enDirect;
      enDirect = !!e.direct;
      if (sessionIngest && e.session && e.session !== sessionIngest && veutRegarder && enDirect && avant) {
        sessionIngest = e.session;
        lancerLecture();
      }
      if (e.session) sessionIngest = e.session;
      const badge = $('badge-direct');
      badge.textContent = enDirect ? 'EN DIRECT' : 'HORS ANTENNE';
      badge.classList.toggle('hors', !enDirect);
      if (enDirect && !avant && veutRegarder && !lecteur.classList.contains('lecture')) lancerLecture();
      if (!enDirect && avant && veutRegarder) { arreterLecture(); messageLecteur('Le direct reprend dans un instant…'); }
      if (e.versionCommentaires !== versionCom) chargerCommentaires();
    } catch { /* réseau : on réessaie au prochain tour */ }
  }

  function ping() {
    if (document.hidden) return;
    const h = { 'Content-Type': 'application/json' };
    if (jeton) h.Authorization = 'Bearer ' + jeton;
    fetch('/api/ping', { method: 'POST', headers: h, body: JSON.stringify({ id: idAppareil }) }).catch(() => {});
  }

  function demarrerBoucles() {
    arreterBoucles();
    rafraichirEtat();
    chargerCommentaires();
    ping();
    verifierVersionApk();
    chargerEnLigne();
    minuteurs = [setInterval(rafraichirEtat, 6000), setInterval(ping, 15000), setInterval(chargerEnLigne, 20000)];
  }
  function arreterBoucles() { for (const m of minuteurs) clearInterval(m); minuteurs = []; }
  document.addEventListener('visibilitychange', () => { if (!document.hidden && moi) { ping(); rafraichirEtat(); } });

  // ---------- infos ----------
  async function chargerInfos() {
    try {
      const d = await api('GET', '/api/infos');
      const box = $('liste-infos');
      box.textContent = '';
      for (const i of d.infos) {
        const art = document.createElement('article');
        art.className = 'carte';
        const t = document.createElement('time');
        t.textContent = new Date(i.t).toLocaleString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
        const h = document.createElement('h3');
        h.textContent = i.titre;
        const p = document.createElement('p');
        p.className = 'texte-info';
        p.textContent = i.texte;
        art.append(t, h, p);
        box.append(art);
      }
      $('aucune-info').hidden = d.infos.length > 0;
    } catch (e) { toast(e.message); }
  }

  // ---------- réglages ----------
  $('case-eco').checked = stockage.lire('rtm.eco') === '1';
  $('case-eco').addEventListener('change', (e) => {
    stockage.ecrire('rtm.eco', e.target.checked ? '1' : null);
    qualite = e.target.checked ? 'eco' : 'auto';
    $('btn-qualite').textContent = NOMS_QUALITE[qualite];
    if (veutRegarder) lancerLecture();
  });

  // ---------- Android (APK) / iPhone / installation ----------
  async function verifierVersionApk() {
    if (!android) return;
    try {
      const v = await api('GET', '/api/version');
      const actuelle = parseFloat(android.version && android.version()) || 1;
      if (parseFloat(v.apk.version) > actuelle) $('bandeau-maj').hidden = false;
    } catch { /* plus tard */ }
  }

  if (android) {
    $('carte-installer').hidden = true;
    $('carte-adresse').hidden = false;
    $('texte-adresse').textContent = location.origin;
    $('btn-changer-adresse').addEventListener('click', () => android.changerAdresse());
  } else if (estAndroid) {
    $('carte-apk').hidden = false;
    $('lien-apk').addEventListener('click', () => {
      const adresse = lienPartage || location.origin + '/';
      try { navigator.clipboard.writeText(adresse).catch(() => {}); } catch { /* */ }
      toast('Téléchargement… Ouvrez ensuite le fichier RTM-Direct.apk.');
    });
  }
  if (estIOS && !installee && stockage.lire('rtm.iosFerme') !== '1') {
    $('bandeau-ios').hidden = false;
    $('fermer-ios').addEventListener('click', () => { $('bandeau-ios').hidden = true; stockage.ecrire('rtm.iosFerme', '1'); });
  }

  let invite = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    invite = e;
    $('btn-installer').hidden = false;
  });
  $('btn-installer').addEventListener('click', async () => {
    if (!invite) return;
    invite.prompt();
    await invite.userChoice.catch(() => {});
    invite = null;
    $('btn-installer').hidden = true;
  });
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }

  // ---------- démarrage : compte obligatoire ----------
  (async function init() {
    if (!jeton) { afficherCompte(); return; }
    try {
      moi = (await api('GET', '/api/moi')).utilisateur;
      entrer();
    } catch (e) {
      // Hors ligne mais déjà connecté : on entre quand même, l'appli se reconnectera.
      if (e.status === 401 || !jeton) afficherCompte();
      else { moi = { nom: 'Moi', mesJaime: 0, horsLigne: true }; entrer(); }
    }
  })();
})();
