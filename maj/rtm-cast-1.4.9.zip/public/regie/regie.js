/* Régie RTM Cast. Tout texte venant des spectateurs est inséré avec textContent. */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  let jeton = null;
  try { jeton = sessionStorage.getItem('rtm.regie'); } catch { /* privé */ }
  let initialisation = false;
  let minuteur = null;

  async function api(methode, chemin, corps) {
    const h = {};
    if (corps !== undefined) h['Content-Type'] = 'application/json';
    if (jeton) h.Authorization = 'Bearer ' + jeton;
    const r = await fetch(chemin, { method: methode, headers: h, body: corps === undefined ? undefined : JSON.stringify(corps), cache: 'no-store' });
    let d = {};
    try { d = await r.json(); } catch { /* vide */ }
    if (r.status === 401 && chemin.startsWith('/api/regie/') && !chemin.endsWith('connexion') && !chemin.endsWith('/auto')) { sortir(); }
    if (!r.ok) throw new Error(d.erreur || 'Serveur injoignable.');
    return d;
  }

  function el(tag, cls, texte) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (texte !== undefined) e.textContent = texte;
    return e;
  }

  const initiale = (n) => (String(n || '?').trim()[0] || '?').toUpperCase();
  function avatar(nom) { const a = el('span', 'avatar', initiale(nom)); a.setAttribute('aria-hidden', 'true'); return a; }

  const date = (t) => new Date(t).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

  function sortir() {
    jeton = null;
    try { sessionStorage.removeItem('rtm.regie'); } catch { /* */ }
    clearInterval(minuteur);
    afficherConnexion();
  }

  async function afficherConnexion() {
    $('ecran-regie').hidden = true;
    $('ecran-connexion').hidden = false;
    try {
      const s = await api('GET', '/api/regie/statut');
      initialisation = !s.initialisee;
    } catch { initialisation = false; }
    $('texte-connexion').textContent = initialisation
      ? 'Première ouverture : choisissez le mot de passe de la régie (12 caractères minimum, mélangez lettres, chiffres et signes). Gardez-le précieusement.'
      : 'Entrez le mot de passe de la régie.';
    $('mdp-regie-2').hidden = !initialisation;
    $('btn-connexion').textContent = initialisation ? 'Créer le mot de passe' : 'Entrer';
    $('mdp-regie').focus();
  }

  $('form-connexion').addEventListener('submit', async (e) => {
    e.preventDefault();
    const mdp = $('mdp-regie').value;
    $('erreur-connexion').textContent = '';
    if (initialisation && mdp !== $('mdp-regie-2').value) { $('erreur-connexion').textContent = 'Les deux mots de passe sont différents.'; return; }
    try {
      const r = await api('POST', initialisation ? '/api/regie/initialiser' : '/api/regie/connexion', { motDePasse: mdp });
      jeton = r.jeton;
      try { sessionStorage.setItem('rtm.regie', jeton); } catch { /* */ }
      $('mdp-regie').value = ''; $('mdp-regie-2').value = '';
      ouvrirRegie();
    } catch (err) { $('erreur-connexion').textContent = err.message; }
  });

  let reglagesRemplis = false;
  async function rafraichir() {
    let e;
    try { e = await api('GET', '/api/regie/etat'); } catch { return; }
    const g = $('etat-global');
    const etat = e.direct ? 'direct' : e.ingest.etat;
    g.textContent = { direct: 'EN DIRECT', attente: 'EN ATTENTE DE vMix', reception: 'CONNEXION…', erreur: 'ERREUR', arret: 'ARRÊTÉ' }[etat] || etat;
    g.className = 'etat ' + (e.direct ? 'direct' : etat === 'attente' ? 'attente' : '');
    $('r-spectateurs').textContent = e.spectateurs;
    $('r-comptes').textContent = e.totaux.utilisateurs;
    $('r-jaime').textContent = e.totaux.jaime;
    $('r-coms').textContent = e.totaux.commentaires;
    $('r-message').textContent = e.ingest.message || '—';
    const i = e.ingest.infos || {};
    $('r-image').textContent = i.resolution ? `${i.resolution} · ${i.ips || '?'} i/s · ${i.video || ''} / ${i.audio || 'pas de son'}` : '—';
    $('r-depuis').textContent = e.ingest.depuis ? date(e.ingest.depuis) : '—';
    $('r-grille').textContent = e.grilleTrouvee ? 'trouvée — « Ensuite » s\'affiche dans l\'appli' : 'introuvable (l\'appli affichera « RTM en direct »)';
    $('r-url').textContent = e.rtmp.url;
    $('r-cle').dataset.cle = e.rtmp.cle;
    if (!$('r-cle').classList.contains('masque')) $('r-cle').textContent = e.rtmp.cle;

    const ul = $('r-adresses');
    ul.textContent = '';
    for (const a of e.adresses) {
      const li = el('li');
      const lien = el('a', '', a);
      lien.href = a; lien.target = '_blank'; lien.rel = 'noopener';
      li.append(lien);
      ul.append(li);
    }
    if (!e.adresses.length) ul.append(el('li', 'aide', 'Aucun réseau détecté : branchez le PC au Wi-Fi / routeur.'));
    afficherTunnel(e);
    afficherMaj(e);
    afficherAlerteLien(e);
    // Tableau de bord : le lien à partager
    const lien = e.lienOfficiel || '';
    $('d-lien').textContent = lien || '—';
    $('d-lien').href = lien || '#';
    $('d-whatsapp').href = 'https://wa.me/?text=' + encodeURIComponent('📺 RTM — Radio Télévision Moba en direct sur votre téléphone ! Touchez le lien, créez votre compte et regardez : ' + lien);
    if (e.incrustation) $('j-incrustation').textContent = `http://localhost:${location.port || 8095}${e.incrustation}`;
    chargerJaime();
    chargerSecurite();
    $('r-journal').textContent = e.journal.slice().reverse().join('\n');

    if (!reglagesRemplis) {
      const r = e.reglages;
      $('g-nom').value = r.nomChaine; $('g-sous').value = r.sousTitre; $('g-youtube').value = r.lienYoutube || '';
      $('g-eco').checked = r.qualiteEco; $('g-distant').checked = r.rtmpBind === '0.0.0.0'; $('g-regie-distante').checked = !!r.regieDistante;
      $('g-publique').value = r.adressePublique || ''; $('g-ffmpeg').value = r.ffmpeg || ''; $('g-grille').value = r.grille || '';
      reglagesRemplis = true;
    }
  }

  // ---------- Mode simple (propriétaire) / technicien ----------
  function modeTechnicien(oui) {
    document.body.classList.toggle('simple', !oui);
    $('btn-technicien').textContent = oui ? '← Revenir à l\'écran simple' : '⚙ Réglages techniques (technicien)';
    try { localStorage.setItem('rtm.technicien', oui ? '1' : '0'); } catch { /* */ }
  }
  $('btn-technicien').onclick = () => modeTechnicien(document.body.classList.contains('simple'));
  try { if (localStorage.getItem('rtm.technicien') === '1') modeTechnicien(true); } catch { /* */ }

  // ---------- Alerte : le lien officiel peut-il mener au direct ? ----------
  function afficherAlerteLien(e) {
    const t = e.tunnel || {};
    const p = e.publication || {};
    const sansAcces = !t.actif;
    const sansPublication = false; // la publication de l'adresse est l'affaire du technicien, pas du propriétaire
    $('alerte-lien').hidden = !(sansAcces || sansPublication);
    $('alerte-acces').hidden = !sansAcces;
    for (const id of ['alerte-github', 'alerte-jeton', 'alerte-enregistrer', 'alerte-etapes']) $(id).hidden = !sansPublication;
    if (sansAcces) {
      $('alerte-titre').textContent = '⚠ Les spectateurs ne peuvent pas regarder : l\'accès Internet est fermé.';
      $('alerte-texte').textContent = 'Le lien officiel et l\'appli Android affichent « pas encore en ligne ». Ouvrez l\'accès Internet.';
    } else if (sansPublication) {
      $('alerte-titre').textContent = '⚠ Le lien officiel ne connaît pas l\'adresse du direct.';
      $('alerte-texte').textContent = 'Les spectateurs qui ouvrent le lien ou l\'appli Android ne trouvent pas RTM. À faire UNE seule fois (2 minutes) :';
    }
  }
  $('alerte-acces').onclick = () => reglerTunnel({ actif: true, mode: 'rapide' });
  $('alerte-enregistrer').onclick = async () => {
    try {
      await api('POST', '/api/regie/publication', { jeton: $('alerte-jeton').value.trim() });
      $('alerte-jeton').value = '';
      alert('Jeton enregistré : l\'adresse du direct va être publiée sur le lien officiel (1 à 10 minutes).');
      rafraichir();
    } catch (err) { alert(err.message); }
  };

  // ---------- Sécurité ----------
  const TYPES = {
    chemin_interdit: 'fichier interdit', scanner: 'outil de piratage', regie_echec: 'mot de passe régie', injection: 'injection',
    connexion_echec: 'mot de passe', jeton_invalide: 'jeton invalide', trop_de_requetes: 'saturation', requete_invalide: 'requête invalide', introuvable: 'exploration',
  };
  async function chargerSecurite() {
    let d;
    try { d = await api('GET', '/api/regie/securite'); } catch { return; }
    $('s-bannis').textContent = d.totalBannis;
    $('s-surveilles').textContent = d.surveilles;
    const ul = $('s-liste');
    ul.textContent = '';
    for (const b of d.bannis) {
      const li = el('li');
      const dv = el('div');
      dv.append(el('div', '', `${b.ip} — ${b.raison}`), el('div', 'meta', `bloquée le ${date(b.depuis)} jusqu'au ${date(b.jusqua)}`));
      const bt = el('button', 'btn petit', 'Débloquer');
      bt.onclick = async () => { await api('POST', '/api/regie/debannir', { ip: b.ip }); chargerSecurite(); };
      li.append(dv, bt);
      ul.append(li);
    }
    if (!d.bannis.length) ul.append(el('li', 'aide', 'Aucune adresse bloquée en ce moment.'));
    $('s-evenements').textContent = d.evenements.slice(0, 40).map((x) => `${date(x.t)}  ${x.ip.padEnd(16)} ${TYPES[x.type] || x.type}  ${x.detail || ''}`).join('\n') || 'Aucune tentative.';
  }
  $('form-bannir').addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await api('POST', '/api/regie/bannir', { ip: $('s-ip').value.trim(), heures: 24 }); $('s-ip').value = ''; chargerSecurite(); }
    catch (err) { alert(err.message); }
  });

  // ---------- J'aime (le propriétaire voit qui aime, et combien de fois) ----------
  async function chargerJaime() {
    let d;
    try { d = await api('GET', '/api/regie/jaime'); } catch { return; }
    $('j-total').textContent = d.total.toLocaleString('fr-FR');
    $('j-personnes').textContent = d.personnes.toLocaleString('fr-FR');
    const r = $('j-recents');
    r.textContent = '';
    for (const x of d.recents.slice(0, 8)) { const li = el('li'); const d = el('div'); d.append(el('div', '', `${x.nom} a aimé${x.n > 1 ? ' ' + x.n + ' fois' : ''}`), el('div', 'meta', date(x.t))); li.append(avatar(x.nom), d, el('span', 'coeur', '❤')); r.append(li); }
    if (!d.recents.length) r.append(el('li', 'aide', 'Pas encore de J\'aime.'));
    const c = $('j-classement');
    c.textContent = '';
    for (const x of d.classement.slice(0, 10)) { const li = el('li'); li.append(el('span', 'nom', x.nom), el('b', '', `${x.n.toLocaleString('fr-FR')} ❤`)); c.append(li); }
  }

  // ---------- Lien officiel, publication, mises à jour ----------
  function afficherMaj(e) {
    const lien = e.lienOfficiel || '';
    $('m-lien').textContent = lien || '—';
    $('m-lien').href = lien || '#';
    $('m-version').textContent = e.version || '?';
    $('m-apk').textContent = e.apk ? `${e.apk.version}` : '—';
    const p = e.publication || {};
    const an = e.annonce || {};
    $('m-publication').textContent = `${an.etat || '—'}${an.cleStation ? ' · clé de station : ' + an.cleStation : ''}${p.configuree ? ' · GitHub : ' + p.etat : ''}`;
    const m = e.maj || {};
    $('m-etat').textContent = m.auto === false ? 'Mise à jour automatique désactivée.' : `État : ${m.etat || '—'}${m.derniereVerif ? ' · vérifiée le ' + date(m.derniereVerif) : ''}`;
    $('m-installer').hidden = !m.disponible;
    if (m.disponible) $('m-installer').textContent = `Installer la version ${m.disponible} maintenant`;
  }
  $('m-verifier').onclick = async () => {
    $('m-etat').textContent = 'Vérification…';
    try { await api('POST', '/api/regie/maj', {}); } catch (err) { $('m-etat').textContent = err.message; }
    rafraichir();
  };
  $('m-installer').onclick = async () => {
    if (!confirm('Installer la mise à jour maintenant ? Le direct sera coupé quelques secondes pendant le redémarrage.')) return;
    try { await api('POST', '/api/regie/maj', { installer: true }); } catch (err) { alert(err.message); }
  };
  $('m-enregistrer-jeton').onclick = async () => {
    try {
      await api('POST', '/api/regie/publication', { jeton: $('m-jeton').value.trim() });
      $('m-jeton').value = '';
      rafraichir();
    } catch (err) { alert(err.message); }
  };

  // ---------- Accès Internet ----------
  let modeChoisi = null;
  function afficherTunnel(e) {
    const t = e.tunnel || {};
    const voyant = $('t-voyant');
    voyant.className = 'voyant ' + (t.etat === 'actif' ? 'vert' : t.etat === 'connexion' ? 'orange' : t.etat === 'erreur' ? 'rouge' : '');
    $('t-message').textContent = t.message || '—';
    if (modeChoisi === null) modeChoisi = t.mode || 'rapide';
    for (const r of document.querySelectorAll('input[name="t-mode"]')) r.checked = r.value === modeChoisi;
    $('t-bloc-jeton').hidden = modeChoisi !== 'fixe';
    $('t-jeton-etat').textContent = t.jetonPresent
      ? 'Jeton enregistré ✓ (jamais affiché). Collez-en un autre pour le remplacer.'
      : 'Cloudflare › Zero Trust › Networks › Tunnels › Create a tunnel › copiez la commande d\'installation et collez-la ici. Puis, dans « Public Hostname », dirigez votre adresse vers http://localhost:' + location.port + '.';
    $('t-activer').hidden = !!t.actif;
    $('t-desactiver').hidden = !t.actif;
    $('t-activer').textContent = modeChoisi === 'fixe' ? 'Ouvrir l\'accès (adresse fixe)' : 'Ouvrir l\'accès (adresse rapide)';

    const adresse = (t.etat === 'actif' && t.mode === 'rapide' && t.url) ? t.url : e.adressePublique;
    const pub = $('r-publique');
    pub.textContent = '';
    if (adresse && (t.etat === 'actif' || !t.actif)) {
      const li = el('li');
      const lien = el('a', '', adresse);
      lien.href = adresse; lien.target = '_blank'; lien.rel = 'noopener';
      const copier = el('button', 'btn petit', 'Copier');
      copier.onclick = async () => {
        try { await navigator.clipboard.writeText(adresse); copier.textContent = 'Copié ✓'; } catch { prompt('Copiez :', adresse); }
        setTimeout(() => { copier.textContent = 'Copier'; }, 1500);
      };
      li.append(lien, copier);
      pub.append(li);
      if (t.etat === 'actif') pub.append(el('li', 'aide', 'Adresse interne (usage technique) : NE PAS la partager. Le lien à partager ne change jamais : ' + (e.lienOfficiel || '') + ' — il retrouve cette adresse tout seul.'));
    }
  }

  async function reglerTunnel(corps) {
    $('t-erreur').textContent = '';
    try { await api('POST', '/api/regie/tunnel', corps); rafraichir(); }
    catch (err) { $('t-erreur').textContent = err.message; }
  }
  for (const r of document.querySelectorAll('input[name="t-mode"]')) {
    r.addEventListener('change', () => {
      modeChoisi = r.value;
      $('t-bloc-jeton').hidden = modeChoisi !== 'fixe';
      rafraichir();
    });
  }
  $('t-activer').onclick = () => reglerTunnel({ actif: true, mode: 'rapide' });
  $('t-desactiver').onclick = () => {
    if (confirm('Fermer l\'accès Internet ? Les spectateurs en 4G perdront le direct.')) reglerTunnel({ actif: false });
  };
  $('t-enregistrer-jeton').onclick = async () => {
    const v = $('t-jeton').value.trim();
    if (!v) return;
    await reglerTunnel({ jeton: v, mode: 'fixe' });
    $('t-jeton').value = '';
  };
  $('t-effacer-jeton').onclick = () => {
    if (confirm('Effacer le jeton Cloudflare ?')) reglerTunnel({ effacerJeton: true, actif: false });
  };

  async function chargerListes() {
    try {
      const vide = (cle) => () => ({ [cle]: [] }); // une liste en échec ne doit pas vider les autres
      const [c, u, inf] = await Promise.all([api('GET', '/api/regie/commentaires').catch(vide('commentaires')), api('GET', '/api/regie/utilisateurs').catch(vide('utilisateurs')), api('GET', '/api/regie/infos').catch(vide('infos'))]);
      const lc = $('r-commentaires');
      lc.textContent = '';
      for (const x of c.commentaires) {
        const li = el('li');
        const d = el('div');
        d.append(el('div', 'meta', `${x.auteur} · ${date(x.t)}`), el('div', '', x.texte));
        const sup = el('button', 'btn petit', 'Supprimer');
        sup.onclick = async () => { await api('POST', '/api/regie/supprimer', { id: x.id }); chargerListes(); };
        const bl = el('button', 'btn petit rouge', 'Bloquer');
        bl.onclick = async () => {
          if (!confirm(`Bloquer ${x.auteur} ? Ses commentaires et J'aime seront retirés.`)) return;
          await api('POST', '/api/regie/bloquer', { utilisateur: x.u }); chargerListes();
        };
        const act = el('div', 'actions'); act.append(sup, bl);
        li.append(avatar(x.auteur), d, act);
        lc.append(li);
      }
      if (!c.commentaires.length) lc.append(el('li', 'aide', 'Aucun commentaire.'));

      const lu = $('r-utilisateurs');
      lu.textContent = '';
      for (const x of u.utilisateurs) {
        const li = el('li');
        const d = el('div');
        d.append(el('div', '', x.nom), el('div', 'meta', `${x.contact} · inscrit le ${date(x.cree)}`));
        if (x.bloque) d.append(el('div', 'bloque', 'BLOQUÉ'));
        const b = el('button', 'btn petit' + (x.bloque ? '' : ' rouge'), x.bloque ? 'Débloquer' : 'Bloquer');
        b.onclick = async () => { await api('POST', x.bloque ? '/api/regie/debloquer' : '/api/regie/bloquer', { utilisateur: x.id }); chargerListes(); };
        li.append(avatar(x.nom), d, b);
        lu.append(li);
      }
      if (!u.utilisateurs.length) lu.append(el('li', 'aide', 'Aucun compte pour le moment.'));

      const li2 = $('r-infos');
      li2.textContent = '';
      for (const x of inf.infos) {
        const li = el('li');
        const d = el('div');
        d.append(el('div', '', x.titre), el('div', 'meta', date(x.t)));
        const s = el('button', 'btn petit', 'Retirer');
        s.onclick = async () => { await api('POST', '/api/regie/infos/supprimer', { id: x.id }); chargerListes(); };
        li.append(d, s);
        li2.append(li);
      }
    } catch { /* réessai */ }
  }

  function ouvrirRegie() {
    $('ecran-connexion').hidden = true;
    $('ecran-regie').hidden = false;
    reglagesRemplis = false;
    rafraichir();
    chargerListes();
    clearInterval(minuteur);
    let n = 0;
    minuteur = setInterval(() => { rafraichir(); if (++n % 5 === 0) chargerListes(); }, 3000);
  }

  // Boutons
  document.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-copier]');
    if (!b) return;
    const c = $(b.dataset.copier);
    const t = c.dataset.cle || c.textContent;
    const libelle = b.textContent;
    try { await navigator.clipboard.writeText(t); b.textContent = 'Copié ✓'; setTimeout(() => { b.textContent = libelle; }, 1500); } catch { prompt('Copiez :', t); }
  });
  $('btn-voir-cle').onclick = () => {
    const c = $('r-cle');
    const masque = c.classList.toggle('masque');
    c.textContent = masque ? '••••••••' : (c.dataset.cle || '');
    $('btn-voir-cle').textContent = masque ? 'Voir' : 'Cacher';
  };
  $('btn-nouvelle-cle').onclick = async () => {
    if (!confirm('Changer la clé ? Il faudra coller la nouvelle clé dans vMix.')) return;
    await api('POST', '/api/regie/nouvelle-cle', {}); rafraichir();
  };
  $('btn-relancer').onclick = async () => { await api('POST', '/api/regie/relancer', {}); rafraichir(); };
  // RTM Cast tourne sans fenêtre : on l'arrête ici (le direct vers l'appli s'arrête).
  $('btn-arreter').onclick = async () => {
    if (!confirm('Arrêter RTM Cast ? Le direct ne sera plus envoyé à l\'appli RTM Direct. Pour le relancer : icône « RTM Cast » sur le Bureau.')) return;
    try { await api('POST', '/api/regie/quitter', {}); document.body.textContent = 'RTM Cast est arrêté. Pour le relancer : icône « RTM Cast » sur le Bureau.'; }
    catch (err) { alert(err.message); }
  };
  $('btn-deconnexion').onclick = async () => { try { await api('POST', '/api/regie/deconnexion', {}); } catch { /* */ } sortir(); };

  $('form-info').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api('POST', '/api/regie/infos', { titre: $('info-titre').value, texte: $('info-texte').value });
      $('info-titre').value = ''; $('info-texte').value = '';
      chargerListes();
    } catch (err) { alert(err.message); }
  });

  $('form-reglages').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api('POST', '/api/regie/reglages', {
        nomChaine: $('g-nom').value, sousTitre: $('g-sous').value, lienYoutube: $('g-youtube').value, qualiteEco: $('g-eco').checked,
        rtmpBind: $('g-distant').checked ? '0.0.0.0' : '127.0.0.1', regieDistante: $('g-regie-distante').checked, adressePublique: $('g-publique').value,
        ffmpeg: $('g-ffmpeg').value, grille: $('g-grille').value,
      });
      $('g-ok').textContent = 'Enregistré. La réception redémarre (relancez Start dans vMix si besoin).';
      reglagesRemplis = false;
      rafraichir();
    } catch (err) { $('g-ok').textContent = err.message; }
  });

  // Sur le PC de diffusion : entrée directe, sans mot de passe.
  (async () => {
    if (jeton) { ouvrirRegie(); return; }
    try {
      const r = await api('POST', '/api/regie/auto', {});
      jeton = r.jeton;
      try { sessionStorage.setItem('rtm.regie', jeton); } catch { /* */ }
      ouvrirRegie();
    } catch { afficherConnexion(); }
  })();
})();
