/* RTM Direct — cache de l'appli (pas du direct). */
const CACHE = 'rtm-direct-v3';
const COQUILLE = ['/', '/app/app.css', '/app/app.js', '/vendor/hls.min.js', '/app/img/embleme.png', '/app/img/icone-192.png', '/app/img/icone-512.png', '/manifest.webmanifest'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(COQUILLE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((n) => n !== CACHE).map((n) => caches.delete(n)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  // Jamais en cache : le direct, l'API, la régie, les photos privées et l'APK.
  if (/^\/(hls|api|regie|photos|telechargement)(\/|$)/.test(url.pathname)) return;
  // Réseau d'abord (pour les mises à jour), cache si pas de connexion.
  e.respondWith(
    fetch(e.request).then((r) => {
      if (r.ok) { const copie = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copie)); }
      return r;
    }).catch(() => caches.match(e.request).then((r) => r || caches.match('/')))
  );
});
